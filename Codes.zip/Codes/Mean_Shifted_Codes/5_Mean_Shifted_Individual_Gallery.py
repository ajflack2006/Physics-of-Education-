
import os
import re
import base64
import io
from pathlib import Path

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe

# ── CONFIG (must match main script) ────────────────────────────────────────────
main_folder         = Path("/home/ajfla/TIMEFOIPROJECT/Physics_Of_Education_Compiled_Data/Lin_PH106_F2024/")
base_output_dir     = main_folder / "test_individual_shifted"
base_csv_output_dir = base_output_dir / "test_individual_csv_files_for_graphs"
GALLERY_FILE        = base_output_dir / "gallery.html"

THUMB_W, THUMB_H = 4.2, 3.2   # inches
THUMB_DPI        = 90


# ── THUMBNAIL RENDERER ──────────────────────────────────────────────────────────
def make_thumbnail_b64(df: pd.DataFrame, student_name: str) -> str:
    """Return a base64-encoded PNG thumbnail of the FOI vs. Time scatter."""

    fig, ax = plt.subplots(figsize=(THUMB_W, THUMB_H), dpi=THUMB_DPI)
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")

    mcq    = df[df["Type"] == "MCQ"]
    nonmcq = df[df["Type"] == "Non-MCQ"]

    # ── density heatmap (quick 2-D histogram as imshow) ──────────────────────
    x_min, x_max = df["FOI"].min() - 0.5, df["FOI"].max() + 0.5
    y_max        = min(int((df["Time"].max() + 9) // 10 * 10) + 10, 48)
    hm, xedge, yedge = np.histogram2d(
        df["FOI"], df["Time"],
        bins=[np.linspace(x_min, x_max, 40), np.linspace(0, y_max, 40)]
    )
    hm_masked = np.where(hm == 0, np.nan, hm)
    ax.imshow(
        hm_masked.T, origin="lower", aspect="auto",
        extent=[xedge[0], xedge[-1], yedge[0], yedge[-1]],
        cmap="Greys", alpha=0.45, interpolation="nearest"
    )

    # ── scatter points ────────────────────────────────────────────────────────
    scatter_kw = dict(linewidths=0.4, edgecolors="#555", alpha=0.85)
    if not mcq.empty:
        ax.scatter(mcq["FOI"], mcq["Time"],
                   s=22, marker="o", color="#e84040", label="MCQ", **scatter_kw)
    if not nonmcq.empty:
        ax.scatter(nonmcq["FOI"], nonmcq["Time"],
                   s=26, marker="^", color="#e84040", label="Non-MCQ", **scatter_kw)

    # ── axes styling ──────────────────────────────────────────────────────────
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(0, y_max)
    ax.set_xlabel("Freak Out Index (FOI)", fontsize=7.5, color="#333")
    ax.set_ylabel("Time (minutes)",        fontsize=7.5, color="#333")
    ax.tick_params(labelsize=6.5, colors="#555")
    for spine in ax.spines.values():
        spine.set_edgecolor("#bbb")
        spine.set_linewidth(0.8)
    ax.grid(False)

    # ── title ─────────────────────────────────────────────────────────────────
    short = student_name if len(student_name) <= 22 else student_name[:20] + "…"
    ax.set_title(f"HW FOI vs. Time: {short}", fontsize=7.5,
                 fontweight="bold", color="#1a1a2e", pad=4)

    # ── compact legend ────────────────────────────────────────────────────────
    handles = []
    from matplotlib.lines import Line2D
    handles.append(Line2D([0],[0], marker='s', color='w',
                          markerfacecolor='#aaa', markersize=6, label='Density'))
    if not mcq.empty:
        handles.append(Line2D([0],[0], marker='o', color='w',
                              markerfacecolor='#e84040', markeredgecolor='#555',
                              markeredgewidth=0.4, markersize=5, label='MCQ'))
    if not nonmcq.empty:
        handles.append(Line2D([0],[0], marker='^', color='w',
                              markerfacecolor='#e84040', markeredgecolor='#555',
                              markeredgewidth=0.4, markersize=5, label='Non-MCQ'))
    ax.legend(handles=handles, fontsize=6, loc="upper left",
              framealpha=0.7, edgecolor="#ccc", handlelength=1.2)

    plt.tight_layout(pad=0.6)

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=THUMB_DPI, bbox_inches="tight",
                facecolor="white")
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")


# ── COLLECT STUDENTS ────────────────────────────────────────────────────────────
print("Scanning student directories…")
students = []

for entry in sorted(base_output_dir.iterdir()):
    if not entry.is_dir():
        continue
    name    = entry.name
    csv_path  = base_csv_output_dir / name / f"{name}_main_plot_data.csv"
    html_path = entry / f"{name}_full_report.html"

    if not csv_path.exists() or not html_path.exists():
        continue

    try:
        df = pd.read_csv(csv_path)
        if df.empty or "FOI" not in df.columns:
            continue
        students.append({
            "name":      name,
            "df":        df,
            "n_points":  len(df),
            "html_rel":  f"{name}/{name}_full_report.html",
        })
        print(f"  ✓  {name}  ({len(df)} pts)")
    except Exception as exc:
        print(f"  ✗  {name}: {exc}")

students.sort(key=lambda s: s["n_points"], reverse=True)
print(f"\nFound {len(students)} students (sorted by data points, most first). Rendering thumbnails…")


# ── RENDER THUMBNAILS ───────────────────────────────────────────────────────────
cards_html = []
for i, s in enumerate(students, 1):
    print(f"  [{i}/{len(students)}] {s['name']}")
    b64 = make_thumbnail_b64(s["df"], s["name"])
    card = f"""
        <a class="card" href="{s['html_rel']}" target="_blank">
          <div class="card-img-wrap">
            <img src="data:image/png;base64,{b64}" alt="{s['name']}" loading="lazy">
          </div>
          <div class="card-body">
            <p class="card-name">Student: {s['name']}</p>
            <p class="card-meta">Data Points: {s['n_points']:,}</p>
          </div>
        </a>"""
    cards_html.append(card)


# ── BUILD HTML ──────────────────────────────────────────────────────────────────
gallery_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Individual Student FOI vs. Time Gallery</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600;700&display=swap');

    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

    body {{
      font-family: 'IBM Plex Sans', 'Segoe UI', sans-serif;
      background: #f4f5f7;
      color: #1a1a2e;
      min-height: 100vh;
    }}

    /* ── header ── */
    header {{
      background: #ffffff;
      border-bottom: 2px solid #e2e5ea;
      padding: 28px 48px 22px;
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: 0 2px 12px rgba(0,0,0,0.06);
    }}
    header h1 {{
      font-size: 1.85rem;
      font-weight: 700;
      letter-spacing: -0.3px;
      color: #111827;
      text-align: center;
    }}
    .subtitle {{
      text-align: center;
      margin-top: 6px;
      font-size: 0.85rem;
      color: #6b7280;
      letter-spacing: 0.2px;
    }}

    /* ── search ── */
    .search-wrap {{
      display: flex;
      justify-content: center;
      margin: 22px auto 0;
      max-width: 420px;
    }}
    #search {{
      width: 100%;
      padding: 9px 16px;
      border: 1.5px solid #d1d5db;
      border-radius: 8px;
      font-family: inherit;
      font-size: 0.88rem;
      background: #f9fafb;
      color: #111;
      outline: none;
      transition: border-color 0.18s;
    }}
    #search:focus {{ border-color: #6366f1; background: #fff; }}

    /* ── grid ── */
    .grid {{
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 24px;
      padding: 36px 48px 56px;
      max-width: 1480px;
      margin: 0 auto;
    }}
    @media (max-width: 1100px) {{ .grid {{ grid-template-columns: repeat(2, 1fr); }} }}
    @media (max-width:  700px) {{ .grid {{ grid-template-columns: 1fr; padding: 20px; }} }}

    /* ── card ── */
    .card {{
      background: #ffffff;
      border: 1.5px solid #e5e7eb;
      border-radius: 12px;
      overflow: hidden;
      text-decoration: none;
      color: inherit;
      display: flex;
      flex-direction: column;
      box-shadow: 0 1px 4px rgba(0,0,0,0.06);
      transition: transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease;
    }}
    .card:hover {{
      transform: translateY(-4px);
      box-shadow: 0 8px 28px rgba(0,0,0,0.12);
      border-color: #a5b4fc;
    }}
    .card-img-wrap {{
      width: 100%;
      background: #fafafa;
      border-bottom: 1px solid #f0f0f0;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    .card-img-wrap img {{
      width: 100%;
      height: auto;
      display: block;
      transition: transform 0.22s ease;
    }}
    .card:hover .card-img-wrap img {{
      transform: scale(1.025);
    }}
    .card-body {{
      padding: 14px 18px 16px;
      display: flex;
      flex-direction: column;
      gap: 3px;
    }}
    .card-name {{
      font-size: 0.92rem;
      font-weight: 600;
      color: #111827;
      line-height: 1.35;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }}
    .card-meta {{
      font-size: 0.82rem;
      color: #6b7280;
      font-weight: 400;
    }}

    /* ── empty state ── */
    #no-results {{
      display: none;
      text-align: center;
      padding: 60px 20px;
      color: #9ca3af;
      font-size: 1rem;
      grid-column: 1 / -1;
    }}
  </style>
</head>
<body>

<header>
  <h1>Individual Student FOI vs. Time Gallery</h1>
  <p class="subtitle">{len(students)} students &nbsp;·&nbsp; sorted by data points (most → fewest) &nbsp;·&nbsp; click any card to open the full interactive report</p>
  <div class="search-wrap">
    <input id="search" type="text" placeholder="Filter by student ID…" autocomplete="off">
  </div>
</header>

<main>
  <div class="grid" id="grid">
    {''.join(cards_html)}
    <p id="no-results">No students match your search.</p>
  </div>
</main>

<script>
  const input = document.getElementById('search');
  const cards = Array.from(document.querySelectorAll('.card'));
  const noRes = document.getElementById('no-results');

  input.addEventListener('input', () => {{
    const q = input.value.trim().toLowerCase();
    let visible = 0;
    cards.forEach(c => {{
      const name = c.querySelector('.card-name').textContent.toLowerCase();
      const show = !q || name.includes(q);
      c.style.display = show ? '' : 'none';
      if (show) visible++;
    }});
    noRes.style.display = visible === 0 ? 'block' : 'none';
  }});
</script>

</body>
</html>
"""

GALLERY_FILE.write_text(gallery_html, encoding="utf-8")
print(f"\n✅  Gallery written to:\n    {GALLERY_FILE}")
print("Open gallery.html in a browser and click any card to view the full report.")