import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots
import os
import glob
import math
import scipy.stats as stats
from scipy.stats import multivariate_normal
import json

# --- CONFIGURATION ---
BASE_PATH = "/home/ajfla/TIMEFOIPROJECT/Physics_Of_Education_Compiled_Data/Lin_PH106_F2024"
TIME_FOI_DIR = f"{BASE_PATH}/Individual_Time_FOI_Mean_Shifted"
CORRECTNESS_DIR = f"{BASE_PATH}"
OUTPUT_DIR = f"{BASE_PATH}/FOI_Reports_Likelihood_Shifted"

os.makedirs(OUTPUT_DIR, exist_ok=True)

def load_and_merge_data():
    all_data = []
    time_files = glob.glob(os.path.join(TIME_FOI_DIR, "*.csv"))

    for t_file in time_files:
        cwid = os.path.basename(t_file).replace('.csv', '')
        try:
            df_student_time = pd.read_csv(t_file)

            # --- Correctness is optional ---
            c_file = os.path.join(CORRECTNESS_DIR, f"{cwid}_correctness.csv")
            has_correctness = os.path.exists(c_file)
            df_corr = None
            if has_correctness:
                df_corr = pd.read_csv(c_file)
                df_corr['HW_MATCH'] = df_corr['HW'].astype(str).str.replace(" ", "").str.upper()

            for _, row in df_student_time.iterrows():
                hw_id_clean = str(row['HW']).replace(" ", "").upper()

                for col_name in df_student_time.columns:
                    if 'FOI' not in col_name:
                        continue

                    q_id = col_name.split(' ')[0].upper()
                    time_col = f"{q_id} TIME"

                    if time_col not in df_student_time.columns:
                        continue

                    foi_val = row[col_name]
                    time_val = row[time_col]

                    if pd.isnull(foi_val) or pd.isnull(time_val):
                        continue

                    # Default: no grade
                    grade_val = np.nan

                    if has_correctness:
                        hw_grades = df_corr[df_corr['HW_MATCH'] == hw_id_clean]
                        if not hw_grades.empty:
                            grade_col = next(
                                (c for c in hw_grades.columns if c.upper() == q_id), None
                            )
                            if grade_col:
                                gv = hw_grades[grade_col].iloc[0]
                                if pd.notnull(gv):
                                    grade_val = gv

                    all_data.append({
                        'Student': cwid,
                        'HW': hw_id_clean,
                        'Question': q_id,
                        'FOI': foi_val,
                        'Time': time_val,
                        'Grade': grade_val,
                    })

        except Exception:
            continue

    return pd.DataFrame(all_data)


def calculate_lrt_2d(df_slice, threshold):
    """Multivariate LRT. Returns (0.0, 1.0) when grades are unavailable."""
    df_slice = df_slice.dropna(subset=['Grade'])
    if df_slice.empty or len(df_slice) < 5:
        return 0.0, 1.0

    pass_df = df_slice[df_slice['Grade'] >= threshold]
    fail_df = df_slice[df_slice['Grade'] < threshold]

    if len(pass_df) < 5 or len(fail_df) < 5:
        return 0.0, 1.0

    X_all = df_slice[['FOI', 'Time']].values
    X_pass = pass_df[['FOI', 'Time']].values
    X_fail = fail_df[['FOI', 'Time']].values

    eps = 1e-6
    mu0 = np.mean(X_all, axis=0)
    cov0 = np.cov(X_all.T) + eps * np.eye(2)
    logL0 = np.sum(multivariate_normal.logpdf(X_all, mean=mu0, cov=cov0))

    mu1 = np.mean(X_pass, axis=0)
    cov1 = np.cov(X_pass.T) + eps * np.eye(2)
    mu2 = np.mean(X_fail, axis=0)
    cov2 = np.cov(X_fail.T) + eps * np.eye(2)

    logL1 = (
        np.sum(multivariate_normal.logpdf(X_pass, mean=mu1, cov=cov1)) +
        np.sum(multivariate_normal.logpdf(X_fail, mean=mu2, cov=cov2))
    )

    lrt_value = max(-2 * (logL0 - logL1), 0.0)
    p_value = 1 - stats.chi2.cdf(lrt_value, df=5)
    return lrt_value, p_value


def calculate_lrt(df_slice, threshold):
    """Univariate LRT. Returns (0.0, 1.0) when grades are unavailable."""
    df_slice = df_slice.dropna(subset=['Grade'])
    if df_slice.empty or len(df_slice) < 2:
        return 0.0, 1.0

    pass_foi = df_slice[df_slice['Grade'] >= threshold]['FOI']
    fail_foi = df_slice[df_slice['Grade'] < threshold]['FOI']

    if len(pass_foi) < 2 or len(fail_foi) < 2:
        return 0.0, 1.0

    mu0, sigma0 = df_slice['FOI'].mean(), df_slice['FOI'].std()
    logL0 = np.sum(stats.norm.logpdf(df_slice['FOI'], loc=mu0, scale=sigma0))

    mu1, sigma1 = pass_foi.mean(), pass_foi.std()
    mu2, sigma2 = fail_foi.mean(), fail_foi.std()
    logL1 = (
        np.sum(stats.norm.logpdf(pass_foi, loc=mu1, scale=sigma1)) +
        np.sum(stats.norm.logpdf(fail_foi, loc=mu2, scale=sigma2))
    )

    lrt_value = max(-2 * (logL0 - logL1), 0.0)
    p_value = 1 - stats.chi2.cdf(lrt_value, df=2)
    return lrt_value, p_value


def create_final_plot(df, title, filename=None):
    if df.empty:
        return None

    grades_available = df['Grade'].notna().any()

    foi_bins = [(-3, -2), (-2, -1), (-1, 0), (0, 1), (1, 2), (2, 3)]
    bin_size = 2
    global threshold
    threshold = 10

    # ------------------------------------------------------------------
    # Data-driven axis bounds
    # ------------------------------------------------------------------
    time_data_min = df['Time'].min()
    time_data_max = df['Time'].max()
    foi_data_min  = df['FOI'].min()
    foi_data_max  = df['FOI'].max()

    hist_x_min = min(0.0, math.floor(time_data_min / bin_size) * bin_size)
    hist_x_max = math.ceil(time_data_max / bin_size) * bin_size

    foi_pad  = max(0.1, (foi_data_max - foi_data_min) * 0.05)
    time_pad = max(1.0, (time_data_max - time_data_min) * 0.05)
    scatter_x_min = foi_data_min  - foi_pad
    scatter_x_max = foi_data_max  + foi_pad
    scatter_y_max = time_data_max + time_pad

    # --- Max bar height for y-axis scaling ---
    max_bar_height = 0
    time_bins = np.arange(hist_x_min, hist_x_max + bin_size, bin_size)
    for low, high in foi_bins:
        mask = (df['FOI'] >= low) & (df['FOI'] < high)
        slice_times = df[mask]['Time']
        if not slice_times.empty:
            counts, _ = np.histogram(slice_times, bins=time_bins)
            if len(counts) > 0:
                max_bar_height = max(max_bar_height, counts.max())

    dynamic_fixed_y_max = max(50, max_bar_height * 1.2)
    y_tick_interval = 10 if dynamic_fixed_y_max < 150 else int(math.ceil(dynamic_fixed_y_max / 10))

    # ------------------------------------------------------------------
    # Layout: 4 columns when grades available, 2 columns otherwise
    # ------------------------------------------------------------------
    if grades_available:
        n_cols = 4
        col_widths = [0.40, 0.15, 0.15, 0.15]
        col_titles = ["Main Distribution", "Total", "Red (Fail)", "Green (Pass)"]
        for low, high in foi_bins:
            label = f"FOI: [{low}, {high})"
            col_titles += [label, label, label]
        specs = [
            [{"rowspan": 6}, {}, {}, {}],
            [None, {}, {}, {}],
            [None, {}, {}, {}],
            [None, {}, {}, {}],
            [None, {}, {}, {}],
            [None, {}, {}, {}],
        ]
    else:
        n_cols = 2
        col_widths = [0.55, 0.40]
        col_titles = ["Main Distribution", "Total"]
        for low, high in foi_bins:
            col_titles += [f"FOI: [{low}, {high})"]
        specs = [
            [{"rowspan": 6}, {}],
            [None, {}],
            [None, {}],
            [None, {}],
            [None, {}],
            [None, {}],
        ]

    fig = make_subplots(
        rows=6, cols=n_cols,
        column_widths=col_widths,
        horizontal_spacing=0.08, vertical_spacing=0.05,
        subplot_titles=col_titles,
        specs=specs,
    )

    # ------------------------------------------------------------------
    # Colour helpers
    # ------------------------------------------------------------------
    NEUTRAL_COLOR = '#3498db'

    def compute_colors(df_in, thresh, mode='both'):
        if not grades_available:
            return [NEUTRAL_COLOR] * len(df_in)
        if mode == 'green':
            return ['#2ecc71' if g >= thresh else 'rgba(0,0,0,0)' for g in df_in['Grade']]
        elif mode == 'red':
            return ['#e74c3c' if g < thresh else 'rgba(0,0,0,0)' for g in df_in['Grade']]
        return [
            '#2ecc71' if pd.notnull(g) and g >= thresh else
            '#e74c3c' if pd.notnull(g) else
            NEUTRAL_COLOR
            for g in df_in['Grade']
        ]

    # ------------------------------------------------------------------
    # Shared histogram kwargs
    # ------------------------------------------------------------------
    hist_xbins = dict(start=hist_x_min, end=hist_x_max, size=bin_size)
    hist_style  = dict(line=dict(color='black', width=1.2))

    # ------------------------------------------------------------------
    # Main scatter plot (col 1, spanning all 6 rows)
    # ------------------------------------------------------------------
    fig.add_trace(go.Scatter(
        x=df['FOI'], y=df['Time'], mode='markers',
        marker=dict(
            color=compute_colors(df, threshold, 'both'),
            size=9, opacity=0.6, line=dict(width=0.5, color='White'),
        ),
        text=[
            f"SID: {s}<br>Grade: {g if pd.notnull(g) else 'N/A'}"
            for s, g in zip(df['Student'], df['Grade'])
        ],
        name='Data',
    ), row=1, col=1)

    # ------------------------------------------------------------------
    # FOI-slice histograms
    # ------------------------------------------------------------------
    grey_indices, red_indices, green_indices = [], [], []

    for i, (low, high) in enumerate(foi_bins):
        mask = (df['FOI'] >= low) & (df['FOI'] < high)
        slice_all = df[mask]
        row_i = i + 1

        # Total (always present)
        fig.add_trace(go.Histogram(
            x=slice_all['Time'],
            marker_color='#bdc3c7', opacity=0.4,
            marker=hist_style,
            xbins=hist_xbins,
            texttemplate="%{y}",
            textposition="outside",
            showlegend=False,
        ), row=row_i, col=2)
        grey_indices.append(len(fig.data) - 1)

        if grades_available:
            # Fail (red)
            fig.add_trace(go.Histogram(
                x=slice_all[slice_all['Grade'] < threshold]['Time'],
                marker_color='#e74c3c', opacity=0.8,
                marker=hist_style,
                xbins=hist_xbins,
                texttemplate="%{y}",
                textposition="outside",
                showlegend=False,
            ), row=row_i, col=3)
            red_indices.append(len(fig.data) - 1)

            # Pass (green)
            fig.add_trace(go.Histogram(
                x=slice_all[slice_all['Grade'] >= threshold]['Time'],
                marker_color='#2ecc71', opacity=0.8,
                marker=hist_style,
                xbins=hist_xbins,
                texttemplate="%{y}",
                textposition="outside",
                showlegend=False,
            ), row=row_i, col=4)
            green_indices.append(len(fig.data) - 1)

    # ------------------------------------------------------------------
    # Grade-threshold slider (only when grades available)
    # ------------------------------------------------------------------
    slider_config = []
    if grades_available:
        steps = []
        for val in range(0, 11):
            new_x = [None] * len(fig.data)
            new_x[0] = df['FOI']

            for i, (low, high) in enumerate(foi_bins):
                mask = (df['FOI'] >= low) & (df['FOI'] < high)
                slice_all = df[mask]
                new_x[grey_indices[i]] = slice_all['Time']
                new_x[red_indices[i]] = slice_all[slice_all['Grade'] < val]['Time']
                new_x[green_indices[i]] = slice_all[slice_all['Grade'] >= val]['Time']

            lrt_dynamic, p_dynamic = calculate_lrt_2d(df, val)

            steps.append(dict(
                method="update",
                label=str(val),
                args=[
                    {
                        "x": new_x,
                        "marker.color": [compute_colors(df, val, 'both')]
                        + [fig.data[j].marker.color for j in range(1, len(fig.data))],
                    },
                    {
                        "annotations": [dict(
                            x=2.5, y=1.05, xref='x', yref='paper',
                            text=f"<b>LRT: {lrt_dynamic:.3f} &nbsp;|&nbsp; p = {p_dynamic:.4f}</b>",
                            showarrow=False,
                            font=dict(size=18, color='darkblue'),
                        )]
                    },
                ],
            ))

        slider_config = [dict(
            active=threshold,
            currentvalue={"prefix": "Grade Threshold: "},
            pad={"t": 30},
            steps=steps,
            len=0.3,
            x=0.05,
        )]

    # ------------------------------------------------------------------
    # Scale-mode relay args
    # Both dicts touch exactly the same set of keys so toggling either
    # direction is a clean full override with no leftover state.
    # ------------------------------------------------------------------
    n_hist_cols = 3 if grades_available else 1

    fixed_scale   = {}
    dynamic_scale = {}

    for row_i, (low, high) in enumerate(foi_bins):
        mask = (df['FOI'] >= low) & (df['FOI'] < high)
        local_times = df[mask]['Time']
        if local_times.empty:
            local_x_max = hist_x_max  # fallback to global max
        else:
            local_x_max = math.ceil(local_times.max() / bin_size) * bin_size
            local_x_max = max(local_x_max, hist_x_min + bin_size)  # at least one bin wide

        # Axis numbering: scatter occupies xaxis1 (col 1, rowspan 6).
        # Histogram axes number sequentially from 2, left-to-right, top-to-bottom:
        #   row 1: xaxis2 [, xaxis3, xaxis4]
        #   row 2: xaxis5 [, xaxis6, xaxis7]  ... etc.
        base_axis = 2 + row_i * n_hist_cols
        for col_offset in range(n_hist_cols):
            k = base_axis + col_offset

            # Fixed — uniform shared range, locked y
            fixed_scale[f"xaxis{k}.autorange"] = False
            fixed_scale[f"xaxis{k}.range"]     = [hist_x_min, hist_x_max]
            fixed_scale[f"yaxis{k}.autorange"] = False
            fixed_scale[f"yaxis{k}.range"]     = [0, dynamic_fixed_y_max]
            fixed_scale[f"yaxis{k}.dtick"]     = y_tick_interval
            fixed_scale[f"yaxis{k}.nticks"]    = 6

            # Dynamic — local x_max per FOI bin, free y
            dynamic_scale[f"xaxis{k}.autorange"] = False
            dynamic_scale[f"xaxis{k}.range"]     = [hist_x_min, local_x_max]
            dynamic_scale[f"yaxis{k}.autorange"] = True
            dynamic_scale[f"yaxis{k}.range"]     = [0, dynamic_fixed_y_max]  # overridden by autorange
            dynamic_scale[f"yaxis{k}.dtick"]     = None
            dynamic_scale[f"yaxis{k}.nticks"]    = 6

    # ------------------------------------------------------------------
    # Scatter-colouring buttons and scale toggle buttons
    # ------------------------------------------------------------------
    update_menus = [
        dict(
            type="buttons", direction="right", active=0,
            x=0.55, xanchor="left", y=1.12,
            buttons=[
                dict(label="Fixed Scaling",   method="relayout", args=[fixed_scale]),
                dict(label="Dynamic Scaling", method="relayout", args=[dynamic_scale]),
            ],
        )
    ]
    if grades_available:
        update_menus.insert(0, dict(
            type="buttons", direction="right", active=0,
            x=0.15, xanchor="left", y=1.12,
            buttons=[
                dict(label="Show All",  method="restyle",
                     args=[{"marker.color": [compute_colors(df, threshold, 'both')]},  [0]]),
                dict(label="Pass Only", method="restyle",
                     args=[{"marker.color": [compute_colors(df, threshold, 'green')]}, [0]]),
                dict(label="Fail Only", method="restyle",
                     args=[{"marker.color": [compute_colors(df, threshold, 'red')]},   [0]]),
            ],
        ))

    # ------------------------------------------------------------------
    # LRT annotation (static note when no grades)
    # ------------------------------------------------------------------
    no_grade_annotation = [] if grades_available else [dict(
        x=0.5, y=1.05, xref='paper', yref='paper',
        text="<i>No correctness data — grade-based analysis unavailable</i>",
        showarrow=False,
        font=dict(size=13, color='grey'),
    )]

    fig.update_layout(
        title=dict(
            text=(
                f"<b>{title}</b><br>"
                f"<sup>N = {len(df)} | Fixed Y-Limit: {int(dynamic_fixed_y_max)}"
                + ("" if grades_available else " | Grades: N/A")
                + "</sup>"
            ),
            x=0.05,
        ),
        template="plotly_white",
        updatemenus=update_menus,
        sliders=slider_config,
        annotations=no_grade_annotation,
        height=1500,
        margin=dict(l=70, r=40, t=150, b=80),
    )

    # ------------------------------------------------------------------
    # Axes
    # ------------------------------------------------------------------
    fig.update_xaxes(
        title_text="FOI (Mean Centered)",
        range=[scatter_x_min, scatter_x_max],
        row=1, col=1,
    )
    fig.update_yaxes(
        title_text="Time (Min)",
        range=[0, scatter_y_max],
        row=1, col=1,
    )

    hist_tickfont = dict(size=9, family='Arial')
    hist_cols = [2, 3, 4] if grades_available else [2]
    for r in range(1, 7):
        for c in hist_cols:
            fig.update_xaxes(
                range=[hist_x_min, hist_x_max], dtick=5, tickangle=0,
                tickfont=hist_tickfont, row=r, col=c, autorange=False,
            )
            fig.update_yaxes(
                range=[0, dynamic_fixed_y_max], dtick=y_tick_interval,
                nticks=6, tickfont=hist_tickfont, row=r, col=c, autorange=False,
            )
            if c == 2:
                fig.update_yaxes(title=dict(text="Count", standoff=10), row=r, col=c)

    if filename:
        fig.write_html(filename)

    return fig, fixed_scale, dynamic_scale


def write_combined_html(figures_dict, output_path):
    """
    Write all figures into a single HTML file with a fixed top-right HW selector dropdown.
    Scale mode (Fixed / Dynamic) is preserved when switching between assignments.
    """
    hw_keys = list(figures_dict.keys())

    options_html = "\n".join(
        f'<option value="{i}"{" selected" if i == 0 else ""}>{key}</option>'
        for i, key in enumerate(hw_keys)
    )

    divs_html = ""
    js_fixed_scales = {}
    js_dynamic_scales = {}

    for i, (key, payload) in enumerate(figures_dict.items()):
        if payload is None or payload[0] is None:
            continue
        fig, fixed_scale, dynamic_scale = payload
        include_js = 'cdn' if i == 0 else False
        fig_html = pio.to_html(fig, full_html=False, include_plotlyjs=include_js)
        display = "block" if i == 0 else "none"
        divs_html += f'<div id="hw_div_{i}" style="display:{display};">\n{fig_html}\n</div>\n'
        js_fixed_scales[str(i)] = fixed_scale
        js_dynamic_scales[str(i)] = dynamic_scale

    fixed_scales_json   = json.dumps(js_fixed_scales)
    dynamic_scales_json = json.dumps(js_dynamic_scales)

    full_html = f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>FOI Reports</title>
  <style>
    body {{ margin: 0; padding: 0; font-family: Arial, sans-serif; }}
    #hw-selector-box {{
      position: fixed;
      top: 15px;
      right: 20px;
      z-index: 9999;
      background: white;
      padding: 8px 14px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.25);
      display: flex;
      align-items: center;
      gap: 10px;
    }}
    #hw-selector-box label {{
      font-weight: bold;
      font-size: 14px;
      white-space: nowrap;
    }}
    #hw_selector {{
      padding: 5px 8px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 4px;
      cursor: pointer;
    }}
  </style>
</head>
<body>
  <div id="hw-selector-box">
    <label for="hw_selector">Assignment:</label>
    <select id="hw_selector" onchange="switchHW(this.value)">
      {options_html}
    </select>
  </div>

  {divs_html}

  <script>
    var fixedScaleArgs   = {fixed_scales_json};
    var dynamicScaleArgs = {dynamic_scales_json};

    // ── Single source of truth for scale mode ──────────────────────────
    // 'fixed' | 'dynamic'
    var currentScaleMode = 'fixed';

    // Intercept Plotly button clicks to track the current scale mode.
    // We use capture=true so this fires before Plotly's own handler.
    document.addEventListener('plotly_buttonclicked', function(e) {{
      var btn = e.detail && e.detail.button;
      if (!btn) return;
      var label = btn.label || '';
      if (label === 'Fixed Scaling')   currentScaleMode = 'fixed';
      if (label === 'Dynamic Scaling') currentScaleMode = 'dynamic';
    }}, true);

    function switchHW(idx) {{
      // Hide all panels, show the selected one
      document.querySelectorAll('[id^="hw_div_"]').forEach(function(d) {{
        d.style.display = 'none';
      }});
      var target = document.getElementById('hw_div_' + idx);
      if (!target) return;
      target.style.display = 'block';

      // Apply whichever scale mode was last active
      var newPlot = target.querySelector('.js-plotly-plot');
      if (newPlot) {{
        var key  = String(idx);
        var args = (currentScaleMode === 'dynamic')
          ? dynamicScaleArgs[key]
          : fixedScaleArgs[key];
        if (args) Plotly.relayout(newPlot, args);
      }}
    }}
  </script>
</body>
</html>"""

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(full_html)


if __name__ == "__main__":
    df_master = load_and_merge_data()

    if not df_master.empty:

        # Only keep points where Time (y-axis) is less than 60
        df_master = df_master[df_master['Time'] < 60].copy()

        hw_order = sorted(
            df_master['HW'].unique(),
            key=lambda x: int(''.join(filter(str.isdigit, x)))
        )

        figures = {}

        figures["All Assignments Combined"] = create_final_plot(
            df_master, "All Assignments Combined"
        )

        for hw in hw_order:
            df_hw = df_master[df_master['HW'] == hw].copy()
            figures[hw] = create_final_plot(df_hw, f"Assignment: {hw}")

        combined_path = f"{OUTPUT_DIR}/FOI_All_Assignments.html"
        write_combined_html(figures, combined_path)

        print(f"Report generated successfully: {combined_path}")