import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import re
import os

plt.rcParams.update({
    'font.size': 14,
    'axes.titlesize': 15,
    'axes.labelsize': 15,
    'xtick.labelsize': 13,
    'ytick.labelsize': 13,
    'legend.fontsize': 13
})


# ------------------------------------------------------------
# STEP 1: Compute per-student means across ALL homeworks
# ------------------------------------------------------------
def compute_student_means(base_path, hw_list):

    student_data = {}

    for hw in hw_list:
        input_csv = f"{base_path}/TIMEFOI_Survey/{hw}PH106_raw.csv"
        df = pd.read_csv(input_csv)

        cols_to_check = df.columns[3:]
        df[cols_to_check] = df[cols_to_check].apply(pd.to_numeric, errors='coerce')

        foi_columns = df.columns[3::2]
        time_columns = df.columns[4::2]

        for _, row in df.iterrows():

            student_id = row[2]   # assuming column 2 is unique student ID

            foi_vals = row[foi_columns].values.astype(float)
            time_vals = row[time_columns].values.astype(float)

            valid = ~np.isnan(foi_vals) & ~np.isnan(time_vals)
            foi_vals = foi_vals[valid]
            time_vals = time_vals[valid]

            if student_id not in student_data:
                student_data[student_id] = {"foi": [], "time": []}

            student_data[student_id]["foi"].extend(foi_vals)
            student_data[student_id]["time"].extend(time_vals)

    # Compute means
    student_means = {}

    for student_id, values in student_data.items():
        student_means[student_id] = {
            "mean_foi": np.mean(values["foi"]),
            "mean_time": np.mean(values["time"])
        }

    return student_means


# ------------------------------------------------------------
# STEP 2: Process each HW using student-specific means
# ------------------------------------------------------------
def process_csv(input_file, output_dir, student_means):

    df = pd.read_csv(input_file)
    cols_to_check = df.columns[3:]
    df[cols_to_check] = df[cols_to_check].apply(pd.to_numeric, errors='coerce')

    foi_columns = df.columns[3::2]
    time_columns = df.columns[4::2]

    shifted_foi_all = []
    shifted_time_all = []

    for index, row in df.iterrows():

        student_id = row[2]

        if student_id not in student_means:
            continue

        mean_foi = student_means[student_id]["mean_foi"]
        mean_time = student_means[student_id]["mean_time"]

        foi_vals = row[foi_columns].values.astype(float)
        time_vals = row[time_columns].values.astype(float)

        valid = ~np.isnan(foi_vals) & ~np.isnan(time_vals)

        shifted_foi = foi_vals[valid] - mean_foi
        shifted_time = time_vals[valid] - mean_time

        shifted_foi_all.extend(shifted_foi)
        shifted_time_all.extend(shifted_time)

    shifted_foi_all = np.array(shifted_foi_all)
    shifted_time_all = np.array(shifted_time_all)

    # -------------------------
    # Scatter Plot
    # -------------------------
    plt.figure(figsize=(10, 6))
    plt.scatter(shifted_foi_all, shifted_time_all,
                facecolors='none',
                edgecolors='blue',
                alpha=0.6)

    plt.xlabel('FOI (Student-Mean Centered)')
    plt.ylabel('TIME (Student-Mean Centered)')
    plt.title('FOI vs TIME (Student-Level Mean Centered)', loc='left')

    output_path = os.path.join(output_dir, "student_mean_centered_scatter.png")
    plt.savefig(output_path)
    plt.close()

    # -------------------------
    # Log Scatter Plot
    # -------------------------
    valid_log = shifted_time_all + 1e-6  # prevent log(0)

    plt.figure(figsize=(10, 6))
    plt.scatter(shifted_foi_all,
                np.log(np.abs(valid_log)),
                facecolors='none',
                edgecolors='green',
                alpha=0.6)

    plt.xlabel('FOI (Student-Mean Centered)')
    plt.ylabel('ln(|TIME|)')
    plt.title('FOI vs ln(TIME) (Student-Level Mean Centered)', loc='left')

    output_path = os.path.join(output_dir, "student_mean_centered_log_scatter.png")
    plt.savefig(output_path)
    plt.close()

    print(f"Saved plots to {output_dir}")


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
if __name__ == "__main__":

    base_path = "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinSpring2025PH106"

    hw_list = []

    while True:
        hw = input("Enter HW number (HW1, HW2...) or 'done': ")
        if hw.lower() == 'done':
            break
        hw_list.append(hw)

    print("\nComputing student-level means across ALL homeworks...")
    student_means = compute_student_means(base_path, hw_list)

    print("Processing each homework with student-specific centering...\n")

    for hw in hw_list:

        input_csv = f"{base_path}/TIMEFOI_Survey/{hw}PH106_raw.csv"
        output_dir = f"{base_path}/Individual_Time_FOI/{hw}Student_Mean_Centered/"
        os.makedirs(output_dir, exist_ok=True)

        process_csv(input_csv, output_dir, student_means)

    print("\nDone.")