import os
import pandas as pd
import numpy as np
import re
from plotly.subplots import make_subplots
import plotly.graph_objects as go
from pathlib import Path
import base64

# --- CONFIG --- #
main_folder = Path("/home/ajfla/TIMEFOIPROJECT/Physics_Of_Education_Compiled_Data/Lin_PH106_F2024/")

input_dir           = main_folder / "Individual_Time_FOI_Not_Mean_Shifted/"
base_output_dir     = main_folder / "test_individual_not_shifted"
base_csv_output_dir = base_output_dir / "test_individual_csv_files_for_graphs"
CWID_LOOKUP_FILE    = base_output_dir / "test_individual_cwid_lookup_table.csv"

# Set to a Path to enable grade colouring, or None to disable
correctness_dir = None
# correctness_dir = main_folder / "Individual_Correctness"

base_output_dir.mkdir(parents=True, exist_ok=True)
base_csv_output_dir.mkdir(parents=True, exist_ok=True)

custom_greyscale = [
    [0.0, "#D9D9D9"],
    [1.0, "#000000"]
]

USE_CORRECTNESS = correctness_dir is not None and Path(correctness_dir).is_dir()


# --- Encoding ---
def encode_cwid_simple(cwid):
    return base64.urlsafe_b64encode(str(cwid).encode()).decode().rstrip("=")

def load_cwid_lookup(file_path):
    if file_path.exists():
        try:
            df = pd.read_csv(file_path)
            return dict(zip(df['Original_CWID'], df['Encoded_CWID']))
        except pd.errors.EmptyDataError:
            return {}
    return {}

def save_cwid_lookup(mapping, file_path):
    df = pd.DataFrame(list(mapping.items()), columns=['Original_CWID', 'Encoded_CWID'])
    df.to_csv(file_path, index=False)

cwid_mapping = load_cwid_lookup(CWID_LOOKUP_FILE)


def get_q_pairs(df):
    foi_cols = sorted(
        [c for c in df.columns if "FOI" in c and re.search(r"Q\d+", c)],
        key=lambda x: int(re.search(r"Q(\d+)", x).group(1))
    )
    time_cols = sorted(
        [c for c in df.columns if "TIME" in c and re.search(r"Q\d+", c)],
        key=lambda x: int(re.search(r"Q(\d+)", x).group(1))
    )
    return list(zip(foi_cols, time_cols))


def get_colors(df_sub, threshold, hide_red=False, hide_green=False):
    colors = []
    for g in df_sub['Grade']:
        if pd.notna(g) and g >= threshold:
            colors.append('rgba(0,0,0,0)' if hide_green else 'green')
        elif pd.isna(g):
            colors.append('gray')
        else:
            colors.append('rgba(0,0,0,0)' if hide_red else 'red')
    return colors


def create_page_layout_html(title, plot_div, sidebar_html_content):
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>{title}</title>
        <style>
            body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;margin:0;background-color:#f8f9fa}}
            .header{{padding:1em 2em;background-color:white;border-bottom:1px solid #dee2e6;box-shadow:0 2px 4px rgba(0,0,0,0.05);}}
            h1{{color:#333;font-size:1.8em;margin:0;}}
            .container{{display:flex;height:calc(100vh - 75px)}}
            .plot-area{{flex:3;padding:1em;overflow-y:auto;background-color:#ffffff;border-radius:8px;margin:1em;box-shadow:0 2px 5px rgba(0,0,0,0.1);min-height:1000px;}}
            .sidebar{{flex:1;padding:1em;border-left:1px solid #dee2e6;background-color:white;border-radius:8px;margin:1em;box-shadow:0 2px 5px rgba(0,0,0,0.1);}}
            .sidebar h2{{font-size:1.2em;border-bottom:2px solid #dee2e6;padding-bottom:0.5em;margin-top:1em;color:#555;}}
            .stats-block{{margin-bottom:1.5em;}}
            .stats-block h2{{font-size:1.1em;border-bottom:1px solid #ccc;padding-bottom:0.3em;margin-top:1em;color:#666;}}
            .stats-block table{{width:100%;border-collapse:collapse;margin-top:0.5em;font-size:0.85em;border:1px solid #e0e0e0;border-radius:5px;overflow:hidden;}}
            .stats-block th,.stats-block td{{text-align:left;padding:10px;border-bottom:1px solid #e0e0e0;}}
            .stats-block th{{background-color:#f8f8f8;font-weight:600;color:#444;}}
            .stats-block tr:nth-child(even){{background-color:#f3f3f3;}}
            .stats-block tr:hover{{background-color:#e9e9e9;}}
            .plot-area .plotly-graph-div{{height:auto !important;min-height:100%;}}
        </style>
    </head>
    <body>
        <div class="header"><h1>{title}</h1></div>
        <div class="container">
            <div class="plot-area">{plot_div}</div>
            <div class="sidebar">{sidebar_html_content}</div>
        </div>
    </body>
    </html>
    """


def create_sidebar_html(stats_html_block):
    return f"<h2>Analysis Tables</h2>{stats_html_block}"


# =========================
# PASS 1 – Load Data
# =========================
print("Pass 1: Identifying students...")

all_student_data_meta = []

for filename in os.listdir(input_dir):
    if not filename.endswith(".csv"):
        continue

    original_cwid = os.path.splitext(filename)[0]

    if original_cwid not in cwid_mapping:
        encoded = encode_cwid_simple(original_cwid)
        cwid_mapping[original_cwid] = encoded
    else:
        encoded = cwid_mapping[original_cwid]

    student_output_dir = base_output_dir / encoded
    student_csv_dir    = base_csv_output_dir / encoded
    student_output_dir.mkdir(exist_ok=True)
    student_csv_dir.mkdir(exist_ok=True)

    # --- Load grades (optional) ---
    grade_map = {}
    if USE_CORRECTNESS:
        correctness_file = Path(correctness_dir) / f"{original_cwid}_correctness.csv"
        if correctness_file.exists():
            try:
                df_corr = pd.read_csv(correctness_file)
                for _, row in df_corr.iterrows():
                    if pd.isna(row.get('HW')):
                        continue
                    hw_val = str(row['HW']).strip()
                    for col in df_corr.columns:
                        if col.startswith('Q') and pd.notna(row[col]):
                            try:
                                q_n = int(re.search(r"Q(\d+)", col).group(1))
                                grade_map[(hw_val, q_n)] = float(row[col])
                            except (ValueError, AttributeError):
                                pass
            except Exception as e:
                print(f"Error reading correctness for {original_cwid}: {e}")

    try:
        df = pd.read_csv(input_dir / filename)
        if "HW" not in df.columns:
            continue

        records = []
        for _, row in df.iterrows():
            hw_val = str(row['HW']).strip() if 'HW' in row else "Unknown"
            for foi_col, time_col in get_q_pairs(row.to_frame().T):
                try:
                    q_num = int(re.search(r"Q(\d+)", foi_col).group(1))
                    foi   = float(row[foi_col])
                    time  = float(row[time_col])
                    grade = grade_map.get((hw_val, q_num), np.nan) if USE_CORRECTNESS else np.nan

                    if np.isfinite(foi) and 0 < time <= 1000:
                        records.append((foi, time, "MCQ" if q_num <= 11 else "Non-MCQ",
                                        q_num, grade, hw_val))
                except:
                    continue

        if not records:
            continue

        df_plot = pd.DataFrame(records, columns=["FOI", "Time", "Type", "Q", "Grade", "HW"])
        df_plot.to_csv(student_csv_dir / f"{encoded}_main_plot_data.csv", index=False)

        all_student_data_meta.append({
            "name":      encoded,
            "df_plot":   df_plot,
            "html_path": f"{encoded}_full_report.html"
        })

    except Exception as e:
        print(f"Error processing {filename}: {e}")

save_cwid_lookup(cwid_mapping, CWID_LOOKUP_FILE)
all_student_data_meta.sort(key=lambda x: x["name"])
print(f"Found {len(all_student_data_meta)} valid students.")


# =========================
# PASS 2 – Generate Reports
# =========================
print("Generating HTML reports...")

for student in all_student_data_meta:

    df_plot      = student["df_plot"]
    student_name = student["name"]
    output_dir   = base_output_dir / student_name
    student_csv_dir = base_csv_output_dir / student_name

    x_min_data = df_plot["FOI"].min()
    x_max_data = df_plot["FOI"].max()
    x_min_plot = x_min_data - 0.5
    x_max_plot = x_max_data + 0.5
    foi_range  = np.arange(int(np.floor(x_min_data)), int(np.ceil(x_max_data)) + 1)

    raw_max_time    = df_plot["Time"].max()
    y_max_plot_main = max(40, min(100, int((raw_max_time + 9) // 10 * 10)))

    # ── sidebar tables ────────────────────────────────────────────────────────
    table1_html = ('<div class="stats-block"><h2>Continuous Analysis</h2>'
                   '<table><tr><th>FOI</th><th># Qs</th><th>Mean</th><th>Variance</th></tr>')
    table2_html = ('<div class="stats-block"><h2>Binned Analysis</h2>'
                   '<table><tr><th>FOI</th><th># Qs</th>'
                   '<th>Binned Mean Time</th><th>Binned Variance</th></tr>')

    time_bin_size           = 2
    global_bins             = np.arange(0, 70 + time_bin_size, time_bin_size)
    time_hist_bins_for_plot = np.arange(0, 71, time_bin_size)

    for foi_level in foi_range:
        foi_df = df_plot[
            (df_plot['FOI'] >= foi_level - 0.5) &
            (df_plot['FOI'] <  foi_level + 0.5)
        ]

        if not foi_df.empty:
            counts, bin_edges = np.histogram(foi_df['Time'], bins=time_hist_bins_for_plot)
            total_obs = counts.sum()
            probs     = counts / total_obs if total_obs > 0 else np.zeros_like(counts, dtype=float)
            hist_df   = pd.DataFrame({'Bin_Start': bin_edges[:-1], 'Bin_End': bin_edges[1:],
                                      'Count': counts, 'Probability': probs})
        else:
            hist_df = pd.DataFrame({
                'Bin_Start':   time_hist_bins_for_plot[:-1],
                'Bin_End':     time_hist_bins_for_plot[1:],
                'Count':       np.zeros(len(time_hist_bins_for_plot) - 1, dtype=int),
                'Probability': np.zeros(len(time_hist_bins_for_plot) - 1, dtype=float)
            })

        hist_df.to_csv(student_csv_dir / f"FOI_{foi_level}_histogram_data.csv", index=False)

        if len(foi_df) < 2:
            table1_html += f"<tr><td>{foi_level}</td><td colspan='3'><i>Not enough data</i></td></tr>"
            table2_html += f"<tr><td>{foi_level}</td><td colspan='3'><i>Not enough data</i></td></tr>"
        else:
            num_q     = len(foi_df)
            mean_t    = foi_df['Time'].mean()
            var_t     = foi_df['Time'].var(ddof=1)
            c_bins, _ = np.histogram(foi_df['Time'], bins=global_bins)
            tot_bins  = np.sum(c_bins)
            mids      = (global_bins[:-1] + global_bins[1:]) / 2
            bm        = np.sum(c_bins * mids) / tot_bins if tot_bins > 0 else 0
            bv        = (np.sum(c_bins * (mids - bm) ** 2) / (tot_bins - 1)
                         if tot_bins > 1 else 0)
            table1_html += (f"<tr><td>{foi_level}</td><td>{num_q}</td>"
                            f"<td>{mean_t:.2f}</td><td>{var_t:.2f}</td></tr>")
            table2_html += (f"<tr><td>{foi_level}</td><td>{num_q}</td>"
                            f"<td>{bm:.2f}</td><td>{bv:.2f}</td></tr>")

    table1_html    += "</table></div>"
    table2_html    += "</table></div>"
    full_stats_block = table1_html + table2_html

    # ── main scatter figure ───────────────────────────────────────────────────
    fig_main = go.Figure()

    x_bins_heatmap = np.linspace(x_min_plot, x_max_plot, 80)
    y_bins_heatmap = np.linspace(0, y_max_plot_main + 2, 80)
    hm_data, _, _  = np.histogram2d(df_plot["FOI"], df_plot["Time"],
                                    bins=[x_bins_heatmap, y_bins_heatmap])

    fig_main.add_trace(go.Heatmap(
        z=np.where(hm_data.T == 0, None, hm_data.T),
        x=x_bins_heatmap, y=y_bins_heatmap,
        colorscale=custom_greyscale,
        colorbar=dict(title='Density'),
        name="Density", legendgroup="Density",
        showlegend=True, opacity=0.6,
        hovertemplate='FOI: %{x:.2f}<br>Time: %{y:.2f}<br>Count: %{z}<extra></extra>'
    ))

    mcq = df_plot[df_plot["Type"] == "MCQ"]
    nm  = df_plot[df_plot["Type"] == "Non-MCQ"]

    traces_to_update  = []
    default_slider_val = 5

    # Marker style branches on whether correctness is active
    if USE_CORRECTNESS:
        color_configs = {k: {i: [] for i in range(11)}
                         for k in ('all', 'no_red', 'no_green')}
        trace_idx = 1

        if not mcq.empty:
            fig_main.add_trace(go.Scatter(
                x=mcq["FOI"], y=mcq["Time"], mode='markers',
                name="MCQ", legendgroup="MCQ",
                marker=dict(symbol='circle', size=9, line=dict(width=0),
                            color=get_colors(mcq, default_slider_val)),
                customdata=mcq[['Q', 'Grade', 'HW']].values, showlegend=True,
                hovertemplate=('HW: %{customdata[2]}<br>Q: %{customdata[0]}<br>'
                               'Grade: %{customdata[1]}<br>FOI: %{x}<br>'
                               'Time: %{y}<br>Type: MCQ<extra></extra>')
            ))
            traces_to_update.append(trace_idx)
            for i in range(11):
                color_configs['all'][i].append(get_colors(mcq, i))
                color_configs['no_red'][i].append(get_colors(mcq, i, hide_red=True))
                color_configs['no_green'][i].append(get_colors(mcq, i, hide_green=True))
            trace_idx += 1

        if not nm.empty:
            fig_main.add_trace(go.Scatter(
                x=nm["FOI"], y=nm["Time"], mode='markers',
                name="Non-MCQ", legendgroup="Non-MCQ",
                marker=dict(symbol='triangle-up', size=10, line=dict(width=0),
                            color=get_colors(nm, default_slider_val)),
                customdata=nm[['Q', 'Grade', 'HW']].values, showlegend=True,
                hovertemplate=('HW: %{customdata[2]}<br>Q: %{customdata[0]}<br>'
                               'Grade: %{customdata[1]}<br>FOI: %{x}<br>'
                               'Time: %{y}<br>Type: Non-MCQ<extra></extra>')
            ))
            traces_to_update.append(trace_idx)
            for i in range(11):
                color_configs['all'][i].append(get_colors(nm, i))
                color_configs['no_red'][i].append(get_colors(nm, i, hide_red=True))
                color_configs['no_green'][i].append(get_colors(nm, i, hide_green=True))

        slider_steps = [
            dict(method="restyle", label=str(v),
                 args=[{"marker.color": color_configs['all'][v]}, traces_to_update])
            for v in range(11)
        ]
        sliders = [dict(active=default_slider_val,
                        currentvalue={"prefix": "Grade Threshold: "},
                        pad={"t": 0, "r": 10}, x=0.55, y=1.1, len=0.25,
                        steps=slider_steps)]
        updatemenus = [dict(
            type="buttons", direction="right", x=0.5, y=1.1, showactive=True,
            buttons=[
                dict(label="Show Both", method="restyle",
                     args=[{"marker.color": color_configs['all'][default_slider_val]},
                           traces_to_update]),
                dict(label="Hide Red", method="restyle",
                     args=[{"marker.color": color_configs['no_red'][default_slider_val]},
                           traces_to_update]),
                dict(label="Hide Green", method="restyle",
                     args=[{"marker.color": color_configs['no_green'][default_slider_val]},
                           traces_to_update]),
            ]
        )]

    else:
        # No correctness: hollow markers with crimson border, no slider/buttons
        for t_type, sym in [("MCQ", "circle"), ("Non-MCQ", "triangle-up")]:
            subset = df_plot[df_plot["Type"] == t_type]
            if subset.empty:
                continue
            fig_main.add_trace(go.Scatter(
                x=subset["FOI"], y=subset["Time"], mode='markers',
                name=t_type, legendgroup=t_type,
                marker=dict(symbol=sym, size=8,
                            line=dict(width=1.5, color='crimson'),
                            color='rgba(255,255,255,0)'),
                customdata=subset[['Q', 'HW']].values, showlegend=True,
                hovertemplate=('HW: %{customdata[1]}<br>Q: %{customdata[0]}<br>'
                               'FOI: %{x}<br>Time: %{y}<extra></extra>')
            ))
        sliders, updatemenus = [], []

    fig_main.update_layout(
        title_text=f"Individual HW FOI vs. Time: {student_name}",
        height=600, width=800, plot_bgcolor="white",
        hovermode="closest",
        margin=dict(l=60, r=60, t=80, b=60),
        sliders    =sliders     if traces_to_update else [],
        updatemenus=updatemenus if traces_to_update else []
    )
    fig_main.update_xaxes(
        title_text="Freak Out Index (FOI)", range=[x_min_plot, x_max_plot],
        autorange=False, tickmode='linear', dtick=1,
        showline=True, mirror=True, linecolor='black', showgrid=False
    )
    fig_main.update_yaxes(
        title_text="Time (minutes)", range=[0, y_max_plot_main],
        autorange=False, showline=True, mirror=True,
        linecolor='black', showgrid=False
    )

    # ── histogram subplots ────────────────────────────────────────────────────
    num_hists      = len(foi_range)
    fig_histograms = make_subplots(
        rows=num_hists, cols=1,
        subplot_titles=[f"Time Distribution for FOI = {i}" for i in foi_range],
        vertical_spacing=0.03
    )

    max_y_count, max_y_prob = 0, 0
    for foi_l in foi_range:
        sub = df_plot[(df_plot['FOI'] >= foi_l - 0.5) & (df_plot['FOI'] < foi_l + 0.5)]
        if not sub.empty:
            c, _ = np.histogram(sub['Time'], bins=time_hist_bins_for_plot)
            max_y_count = max(max_y_count, c.max())
            if c.sum() > 0:
                max_y_prob = max(max_y_prob, (c / c.sum()).max())

    y_up_counts = {f'yaxis{j+1}.range': [0, max_y_count * 1.1] for j in range(num_hists)}
    y_up_probs  = {f'yaxis{j+1}.range': [0, max_y_prob  * 1.1] for j in range(num_hists)}
    c_vis, p_vis = [], []

    for i, foi_l in enumerate(foi_range):
        sub     = df_plot[(df_plot['FOI'] >= foi_l - 0.5) & (df_plot['FOI'] < foi_l + 0.5)]
        centers = (time_hist_bins_for_plot[:-1] + time_hist_bins_for_plot[1:]) / 2
        if sub.empty:
            fig_histograms.add_trace(
                go.Scatter(x=[35], y=[0], mode='text', text=['No data'], showlegend=False),
                row=i+1, col=1)
            for _ in range(3):
                fig_histograms.add_trace(go.Scatter(visible=False), row=i+1, col=1)
            c_vis.extend([True, False, False, False])
            p_vis.extend([True, False, False, False])
        else:
            cnts, _ = np.histogram(sub['Time'], bins=time_hist_bins_for_plot)
            probs   = cnts / cnts.sum()
            fig_histograms.add_trace(
                go.Bar(x=centers, y=cnts,  width=2, marker_color='skyblue',
                       showlegend=False), row=i+1, col=1)
            fig_histograms.add_trace(
                go.Scatter(x=centers, y=cnts,  mode='lines',
                           line=dict(color='darkblue', dash='dot'),
                           showlegend=False), row=i+1, col=1)
            fig_histograms.add_trace(
                go.Bar(x=centers, y=probs, width=2, marker_color='lightcoral',
                       showlegend=False), row=i+1, col=1)
            fig_histograms.add_trace(
                go.Scatter(x=centers, y=probs, mode='lines',
                           line=dict(color='red', dash='dot'),
                           showlegend=False), row=i+1, col=1)
            c_vis.extend([True,  True,  False, False])
            p_vis.extend([False, False, True,  True])

    fig_histograms.update_layout(
        height=250 * num_hists, width=800, plot_bgcolor="white",
        updatemenus=[go.layout.Updatemenu(
            type="buttons", direction="right", x=0.01, y=1.01,
            buttons=[
                dict(label="Counts",      method="update",
                     args=[{"visible": c_vis}, y_up_counts]),
                dict(label="Probability", method="update",
                     args=[{"visible": p_vis}, y_up_probs])
            ]
        )]
    )
    fig_histograms.update_xaxes(
        range=[-0.5, 70.5], showline=True, mirror=True, linecolor='black')

    # ── assemble & write HTML ─────────────────────────────────────────────────
    main_plot_html = fig_main.to_html(
        full_html=False, include_plotlyjs='cdn', div_id='main-plot')
    hist_html = fig_histograms.to_html(
        full_html=False, include_plotlyjs='cdn')

    combined_plot_div = (
        f"<div>{main_plot_html}</div>"
        f"\n<br><h2>Individual FOI Time Distributions</h2><br>"
        f"\n<div>{hist_html}</div>"
    )

    full_html = create_page_layout_html(
        f"Analysis for: {student_name}",
        combined_plot_div,
        create_sidebar_html(full_stats_block)
    )

    with open(output_dir / student["html_path"], "w", encoding="utf-8") as f:
        f.write(full_html)

    print(f"Generated report for '{student_name}'")


# =========================
# INDEX PAGE
# =========================
index_path = base_output_dir / "index.html"

with open(index_path, "w") as f:
    f.write('<!DOCTYPE html><html><head><style>'
            'body{font-family:Arial;display:flex;margin:0;height:100vh}'
            '.sidebar{width:250px;background:#f8f9fa;overflow-y:auto;padding:20px;border-right:1px solid #ddd}'
            '.main{flex:1}iframe{width:100%;height:100%;border:none}'
            'a{display:block;padding:8px;color:#007bff;text-decoration:none}'
            'a:hover{background:#eee}'
            '</style></head><body>'
            '<div class="sidebar"><h2>Students</h2>')
    for s in all_student_data_meta:
        f.write(f'<a href="./{s["name"]}/{s["html_path"]}" target="frame">{s["name"]}</a>')
    f.write('</div><div class="main"><iframe name="frame"></iframe></div></body></html>')

print("Script finished successfully.")