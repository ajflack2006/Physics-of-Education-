import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import re
import subprocess

plt.rcParams.update({
    'font.size': 14,
    'axes.titlesize': 16,
    'axes.labelsize': 15,
    'xtick.labelsize': 13,
    'ytick.labelsize': 13,
    'legend.fontsize': 12
})


def extract_hw_number(folder_name):
    match = re.search(r'\d+', folder_name)
    return int(match.group()) if match else None


def regression_with_se(x, y):
    n = len(x)
    slope, intercept = np.polyfit(x, y, 1)

    y_pred = slope * x + intercept
    residuals = y - y_pred
    s_err = np.sqrt(np.sum(residuals**2) / (n - 2))

    x_mean = np.mean(x)
    Sxx = np.sum((x - x_mean)**2)

    slope_se = s_err / np.sqrt(Sxx)

    return slope, slope_se


def collect_B_values(base_directory):

    records = []

    for folder in os.listdir(base_directory):

        if not folder.startswith("HW"):
            continue

        hw_path = os.path.join(base_directory, folder)

        # ---- Robust averages file detection ----
        averages_file = None
        for file in os.listdir(hw_path):
            if "TimeFOI_averages" in file and file.endswith(".csv"):
                averages_file = os.path.join(hw_path, file)
                break

        if averages_file is None:
            continue

        df = pd.read_csv(averages_file)
        df = df[df["Questions"] != "Avg and Sum"]

        foi = df["FOI Average"].values
        ln_time = df["ln(Time Average)"].values

        slope, slope_se = regression_with_se(foi, ln_time)

        hw_num = extract_hw_number(folder)

        records.append((hw_num, slope, slope_se, folder))

    # ---- Sort by actual homework number ----
    records.sort(key=lambda x: x[0])

    # ---- Sequential index (1..N) ----
    seq_numbers = np.arange(1, len(records) + 1)

    B_values = np.array([r[1] for r in records])
    B_errors = np.array([r[2] for r in records])
    labels = [r[3] for r in records]

    return seq_numbers, B_values, B_errors, labels


if __name__ == "__main__":

    base_directory = "/home/ajfla/TIMEFOIPROJECT/Physics_Of_Education_Compiled_Data/Lin_PH106_F2024"

    seq_numbers, B_values, B_errors, labels = collect_B_values(base_directory)

    plt.figure(figsize=(10, 6))

    plt.plot(seq_numbers, B_values, marker='o', label="B values")

    plt.errorbar(
        seq_numbers,
        B_values,
        yerr=1.96 * B_errors,
        fmt='none',
        capsize=4
    )

    plt.xlabel("Homework Index")
    plt.ylabel("B Value (Slope)")
    plt.title("Slope (B) Across Homeworks for Spring 2025 PH106\n\n", loc='left')

    plt.xticks(seq_numbers)   # evenly spaced 1..N

    plt.grid(alpha=0.25)
    plt.legend(frameon=False)

    output_file = os.path.join(
        base_directory,
        "All_Homeworks_B_values_PUBLICATION.png"
    )

    plt.tight_layout()
    plt.savefig(output_file, dpi=300)
    plt.close()

    print(f"Publication-ready B plot saved to {output_file}")
subprocess.run(["python", "10_Averaged_HW_Gallery_C_values.py"])
