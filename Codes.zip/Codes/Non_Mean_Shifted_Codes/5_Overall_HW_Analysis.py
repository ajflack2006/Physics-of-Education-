import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from pathlib import Path
import subprocess


# ============================================================
# BUILD PLOT
# ============================================================

def build_plot(foi, time, grade=None, title="", output_html="output.html"):

    use_grades = grade is not None

    thresholds = list(range(1, 11))

    tmin = float(np.min(time))
    tmax = float(np.max(time))

    fig = make_subplots(
        rows=6,
        cols=5,
        column_widths=[0.50, 0.12, 0.12, 0.12, 0.14],
        vertical_spacing=0.05,
        specs=[
            [{"rowspan": 6}, {}, {}, {}, {}],
            [None, {}, {}, {}, {}],
            [None, {}, {}, {}, {}],
            [None, {}, {}, {}, {}],
            [None, {}, {}, {}, {}],
            [None, {}, {}, {}, {}],
        ]
    )

    # ============================================================
    # FRAMES (ONLY IF USING GRADES)
    # ============================================================

    frames = []

    if use_grades:
        for t in thresholds:

            green_mask = grade >= t
            red_mask = grade < t

            frame_data = []

            # Scatter green
            frame_data.append(
                go.Scatter(
                    x=foi[green_mask],
                    y=time[green_mask],
                    mode="markers",
                    marker=dict(color="#2E8B57", size=12, opacity=0.8)
                )
            )

            # Scatter red
            frame_data.append(
                go.Scatter(
                    x=foi[red_mask],
                    y=time[red_mask],
                    mode="markers",
                    marker=dict(color="#B22222", size=12, opacity=0.8)
                )
            )

            # Column 2 static histograms
            for f in range(6):
                mask = foi == f
                tvals = time[mask]
                counts, bins = np.histogram(tvals, bins=20)
                centers = (bins[:-1] + bins[1:]) / 2

                frame_data.append(
                    go.Bar(
                        x=centers,
                        y=counts,
                        marker=dict(color="#b2f0f0", line=dict(color="black", width=1))
                    )
                )

            # Column 3 green
            for f in range(6):
                mask = (foi == f) & (grade >= t)
                tvals = time[mask]

                if len(tvals) == 0:
                    frame_data.append(go.Bar(x=[], y=[]))
                    continue

                counts, bins = np.histogram(tvals, bins=20)
                centers = (bins[:-1] + bins[1:]) / 2

                frame_data.append(
                    go.Bar(
                        x=centers,
                        y=counts,
                        marker=dict(color="#2E8B57", line=dict(color="black", width=1))
                    )
                )

            # Column 4 red
            for f in range(6):
                mask = (foi == f) & (grade < t)
                tvals = time[mask]

                if len(tvals) == 0:
                    frame_data.append(go.Bar(x=[], y=[]))
                    continue

                counts, bins = np.histogram(tvals, bins=20)
                centers = (bins[:-1] + bins[1:]) / 2

                frame_data.append(
                    go.Bar(
                        x=centers,
                        y=counts,
                        marker=dict(color="#B22222", line=dict(color="black", width=1))
                    )
                )

            # Column 5 labels
            for r in range(6):
                frame_data.append(
                    go.Scatter(
                        x=[0],
                        y=[0],
                        text=[f"<b>FOI {r}</b>"],
                        mode="text",
                        showlegend=False
                    )
                )

            frames.append(go.Frame(name=str(t), data=frame_data))

        fig.frames = frames

    # ============================================================
    # INITIAL TRACES
    # ============================================================

    # Scatter
    if use_grades:
        fig.add_trace(
            go.Scatter(
                x=foi,
                y=time,
                mode="markers",
                marker=dict(color="#2E8B57", size=10)
            ),
            row=1, col=1
        )

        fig.add_trace(
            go.Scatter(
                x=[],
                y=[],
                mode="markers",
                marker=dict(color="#B22222", size=10)
            ),
            row=1, col=1
        )
    else:
        fig.add_trace(
            go.Scatter(
                x=foi,
                y=time,
                mode="markers",
                marker=dict(color="#1f77b4", size=10)
            ),
            row=1, col=1
        )

    # Column 2 static histograms
    for f in range(6):
        mask = foi == f
        tvals = time[mask]
        counts, bins = np.histogram(tvals, bins=20)
        centers = (bins[:-1] + bins[1:]) / 2

        fig.add_trace(
            go.Bar(
                x=centers,
                y=counts,
                marker=dict(color="#b2f0f0", line=dict(color="black", width=1))
            ),
            row=f + 1, col=2
        )

    # Columns 3 and 4 only if using grades
    if use_grades:
        t0 = thresholds[0]

        for f in range(6):
            mask = (foi == f) & (grade >= t0)
            tvals = time[mask]
            counts, bins = np.histogram(tvals, bins=20)
            centers = (bins[:-1] + bins[1:]) / 2

            fig.add_trace(
                go.Bar(
                    x=centers,
                    y=counts,
                    marker=dict(color="#2E8B57", line=dict(color="black", width=1))
                ),
                row=f + 1, col=3
            )

        for f in range(6):
            mask = (foi == f) & (grade < t0)
            tvals = time[mask]
            counts, bins = np.histogram(tvals, bins=20)
            centers = (bins[:-1] + bins[1:]) / 2

            fig.add_trace(
                go.Bar(
                    x=centers,
                    y=counts,
                    marker=dict(color="#B22222", line=dict(color="black", width=1))
                ),
                row=f + 1, col=4
            )

    # FOI labels
    for r in range(6):
        fig.add_trace(
            go.Scatter(
                x=[0],
                y=[0],
                text=[f"<b>FOI {r}</b>"],
                mode="text",
                showlegend=False
            ),
            row=r + 1, col=5
        )

    # ============================================================
    # LAYOUT
    # ============================================================

    sliders = []
    updatemenus = []

    if use_grades:

        steps = [
            dict(
                method="animate",
                label=str(t),
                args=[[str(t)], {"mode": "immediate",
                                 "frame": {"duration": 0, "redraw": True}}]
            )
            for t in thresholds
        ]

        sliders = [dict(active=4,
                        currentvalue={"prefix": "Min Grade: "},
                        steps=steps)]

    fig.update_layout(
        title=f"FOI vs Time Distribution — {title}",
        width=2200,
        height=1400,
        showlegend=False,
        sliders=sliders
    )

    fig.update_xaxes(title="Freak Out Index (FOI)",
                     range=[-0.5, 5.5],
                     dtick=1,
                     row=1, col=1)

    fig.update_yaxes(title="Time (minutes)",
                     range=[0, tmax],
                     row=1, col=1)

    for r in range(1, 7):
        for c in [2, 3, 4]:
            fig.update_xaxes(title_text="Time (minutes)",
                             range=[tmin, tmax],
                             row=r, col=c)
            fig.update_yaxes(title_text="Count",
                             row=r, col=c)

    for r in range(1, 7):
        fig.update_xaxes(visible=False, row=r, col=5)
        fig.update_yaxes(visible=False, row=r, col=5)

    fig.write_html(output_html)
    print("Interactive dashboard saved:", output_html)


# ============================================================
# DATA EXTRACTION
# ============================================================

def extract_data(input_file, grade_file=None):

    df = pd.read_csv(input_file)

    grades = None

    if grade_file is not None:
        grades_df = pd.read_csv(grade_file)
        hw_name = Path(input_file).parent.name

        grade_lookup = {}
        for _, row in grades_df.iterrows():
            hw = str(row.iloc[0]).strip()
            grade_lookup[hw] = pd.to_numeric(row.iloc[1:], errors="coerce").values

        grades = grade_lookup.get(hw_name)

    df = df[~df.iloc[:, 0].astype(str).str.startswith("Average", na=False)]

    foi_columns = df.columns[3::2]
    time_columns = df.columns[4::2]

    foi_list = []
    time_list = []
    grade_list = []

    for q_index, (foi_col, time_col) in enumerate(zip(foi_columns, time_columns)):

        q_grade = grades[q_index] if grades is not None else None

        for _, row in df.iterrows():

            foi_val = row[foi_col]
            time_val = row[time_col]

            if pd.isna(foi_val) or pd.isna(time_val):
                continue

            foi_list.append(foi_val)
            time_list.append(time_val)

            if grades is not None:
                grade_list.append(q_grade)

    if grades is not None:
        return np.array(foi_list), np.array(time_list), np.array(grade_list)
    else:
        return np.array(foi_list), np.array(time_list), None


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    home_dir = Path.home()

    main_folder = home_dir / "TIMEFOIPROJECT/Physics_Of_Education_Compiled_Data/Lin_PH106_F2024/"
    grade_dir = main_folder / "Individual_Correctness"

    grade_files = list(grade_dir.glob("*.csv"))
    grade_file = grade_files[0] if grade_files else None

    while True:

        hw_number = input("Enter HW number (HW1 etc), 'all', or 'done': ")

        if hw_number == "done":
            subprocess.run(["python", "6_Detailed_homeworks_gallery.py"])
            break

        input_csv = main_folder / f"{hw_number}/{hw_number}106Lin_processed_output.csv"
        output_html = main_folder / "Overall_HW_Analysis" / f"{hw_number}_interactive_dashboard.html"
        output_html.parent.mkdir(exist_ok=True)

        if input_csv.exists():
            foi, time, grade = extract_data(input_csv, grade_file)
            build_plot(foi, time, grade, hw_number, output_html)
        else:
            print(f"File not found: {input_csv}")