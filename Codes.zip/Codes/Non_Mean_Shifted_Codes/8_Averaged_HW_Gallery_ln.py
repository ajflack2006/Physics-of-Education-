import os  #<-- 1. REMOVED
from pathlib import Path
import re
import webbrowser
import subprocess


# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---
# HTML STYLING: 
# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---
HTML_STYLE = """
<style>
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        background-color: #f0f2f5;
        margin: 0;
        padding: 20px;
    }
    .page-wrapper {
        max-width: 1600px;
        margin: 0 auto;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        padding: 20px 40px;
    }
    h1 {
        text-align: center;
        color: #1c1e21;
        border-bottom: 2px solid #e7e7e7;
        padding-bottom: 15px;
        margin-bottom: 30px;
    }
    .gallery-container {
        display: flex;
        flex-wrap: wrap;
        gap: 20px; /* Space between gallery items */
        justify-content: center; /* Center items if they don't fill a full row */
    }
    .analysis-section {
        flex: 1 1 300px; /* Allows items to grow/shrink from a base of 300px */
        max-width: 23%; /* Aims for 4 items per row */
        display: flex;
        flex-direction: column;
        margin-bottom: 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        background-color: #fafafa;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    .analysis-section:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .analysis-section h2 {
        color: #333;
        margin-top: 0;
        padding-bottom: 10px;
        border-bottom: 1px solid #ccc;
        font-size: 1em; /* Smaller font for gallery titles */
        text-align: center;
    }
    .analysis-section img {
        width: 100%; /* Image will fill its container */
        height: auto;
        display: block;
        border-radius: 5px;
    }
    /* Responsive design for smaller screens */
    @media (max-width: 1400px) {
        .analysis-section { max-width: 30%; } /* 3 per row */
    }
    @media (max-width: 992px) {
        .analysis-section { max-width: 45%; } /* 2 per row */
    }
    @media (max-width: 768px) {
        .analysis-section { max-width: 90%; } /* 1 per row */
    }
</style>
"""

def create_html_gallery(image_directory, output_html_path):
    """
    Scans a directory for PNG files, sorts them, and creates an HTML file
    to display them in a gallery format.

    Args:
        image_directory (Path): The path to the folder containing the .png images.
        output_html_path (Path): The path where the output .html file will be saved.
    """
    print(f"Scanning for PNG images in: {image_directory}")
    
    # Find all .png files in the given directory
    try:
        # --- 2. UPDATED: Use pathlib to list files instead of os.listdir ---
        image_files = sorted(
            [f.name for f in image_directory.iterdir() if f.suffix.lower() == '.png'],
            # This 'key' sorts files naturally (e.g., HW1, HW2, ..., HW10)
            key=lambda x: [int(c) if c.isdigit() else c for c in re.split(r'(\d+)', x)]
        )
    except FileNotFoundError:
        print(f"Error: The directory '{image_directory}' was not found.")
        return

    if not image_files:
        print("No PNG images found in the directory. HTML file not created.")
        return

    print(f"Found {len(image_files)} images. Generating HTML gallery...")

    # Ensure the output directory exists
    output_html_path.parent.mkdir(parents=True, exist_ok=True)

    # Start building the HTML content
    html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Averaged_HW_Gallery_lny</title>
    {HTML_STYLE}
</head>
<body>
    <div class="page-wrapper">
        <h1>Averaged_HW_Gallery_ln</h1>
        <div class="gallery-container">
"""

    # Loop through each found image and add it to the HTML
    for image_file in image_files:
        # Create a clean title from the filename
        title = image_file.split('PH106')[0].replace('_', ' ').strip() + " Analysis"
        
        # This converts the path to a "file:///..." URL that browsers understand.
        #image_path_uri = (image_directory / image_file).as_uri()

        # --- NEW RELATIVE PATH LOGIC ---
        # 1. Calculate the path from the HTML file's parent directory to the image directory
        relative_image_dir = os.path.relpath(image_directory, output_html_path.parent)
        
        # 2. Join the path and convert to string, ensuring forward slashes for HTML
        # We wrap relative_image_dir in Path() to allow the / operator
        image_path_uri = str(Path(relative_image_dir) / image_file).replace(os.path.sep, '/')
        # -------------------------------

        html_content += f"""
            <div class="analysis-section">
                <h2>{title}</h2>
                <img src="{image_path_uri}" alt="Analysis for {title}">
            </div>
"""

    # Close the HTML tags
    html_content += """
        </div>
    </div>
</body>
</html>
"""

    # Write the generated HTML to the output file
    with open(output_html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"Successfully created gallery: {output_html_path}")
    
    # Automatically open the HTML file in a new browser tab
    webbrowser.open_new_tab(output_html_path.as_uri())
    print("Opening gallery in your default web browser...")


if __name__ == "__main__":
    home_dir = Path.home()
    
    # --- 3. UPDATED: MAIN CONFIGURATION ---
    # Just like the other scripts, you only need to change this one line.
    main_folder = home_dir / "TIMEFOIPROJECT/LinResearchData/WangPH253/"
    # ------------------------------------

    
    # --- Configuration ---
    # These paths are now built from the 'main_folder' variable
    default_image_dir = main_folder / "Averaged_HW_Analysis/ln/"
    output_html_file = main_folder / "Gallery/8_Averaged_HW_Gallery_ln.html"

    print("--- HTML Gallery Generator ---")
    print(f"This script will look for images in: '{default_image_dir}'")
    
    use_default = input("Use this default directory? (yes/no): ").strip().lower()
    
    if use_default in ['yes', 'y', '']:
        image_dir_to_scan = default_image_dir
    else:
        # If user provides a custom directory, save the gallery inside that directory
        custom_dir_str = input("Enter the full path to the image directory: ")
        image_dir_to_scan = Path(custom_dir_str)
        output_html_file = image_dir_to_scan / "gallery.html"
        
    create_html_gallery(image_dir_to_scan, output_html_file)
