import os
import pandas as pd
import re
import numpy as np
from collections import defaultdict

# ------------------------------------------------------------
# PATHS
# ------------------------------------------------------------
main_folder = "/home/ajfla/TIMEFOIPROJECT/Physics_Of_Education_Compiled_Data/Lin_PH106_F2024/"

raw_dir = os.path.join(main_folder, "Raw_Data/")
output_dir = os.path.join(main_folder, "Individual_Time_FOI_Not_Mean_Shifted/")

os.makedirs(output_dir, exist_ok=True)

raw_files = [f"HW{i}PH106F24_raw.csv" for i in range(1, 14)]

# ------------------------------------------------------------
# HELPERS
# ------------------------------------------------------------
def clean_columns(df):
    df.columns = [
        col.strip()
           .replace('\xa0', ' ')
           .replace(":", "")
           .upper()
        for col in df.columns
    ]
    return df


def extract_sorted_columns(df, kind):
    return sorted(
        [col for col in df.columns if kind in col and re.search(r"Q\d+", col)],
        key=lambda x: int(re.search(r"Q(\d+)", x).group(1))
    )

# ------------------------------------------------------------
# STORAGE
# ------------------------------------------------------------
student_records = defaultdict(list)

# ------------------------------------------------------------
# MAIN LOOP (NO CENTERING)
# ------------------------------------------------------------
for hw_index, raw_file in enumerate(raw_files, start=1):

    hw_path = os.path.join(raw_dir, raw_file)
    if not os.path.exists(hw_path):
        print(f"⚠️ Missing: {hw_path}")
        continue

    df = pd.read_csv(hw_path, dtype={"CWID": str})
    df = clean_columns(df)

    if "CWID" not in df.columns:
        print(f"❌ Missing CWID in {raw_file}")
        continue

    foi_cols = extract_sorted_columns(df, "FOI")
    time_cols = extract_sorted_columns(df, "TIME")
    data_cols = foi_cols + time_cols

    # clean numeric + remove extreme values
    for col in data_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')
        df.loc[df[col] > 180, col] = np.nan

    # --------------------------------------------------------
    # PROCESS EACH STUDENT ROW
    # --------------------------------------------------------
    for _, row in df.iterrows():

        cwid_raw = row.get("CWID")
        if pd.isna(cwid_raw):
            continue

        cwid = str(cwid_raw).strip().replace(".0", "")

        # build output row — FOI and TIME stored as-is
        hw_row = {"HW": f"HW{hw_index}"}

        for col in foi_cols:
            hw_row[col] = row.get(col, np.nan)

        for col in time_cols:
            hw_row[col] = row.get(col, np.nan)

        student_records[cwid].append(hw_row)

# ------------------------------------------------------------
# SAVE OUTPUT PER STUDENT
# ------------------------------------------------------------
for cwid, hw_rows in student_records.items():

    df_student = pd.DataFrame(hw_rows)

    existing_cols = [c for c in df_student.columns if c != "HW"]

    question_cols = sorted(
        existing_cols,
        key=lambda x: (
            int(re.search(r"Q(\d+)", x).group(1)),
            "TIME" in x
        )
    )

    df_student = df_student[["HW"] + question_cols]

    df_student.to_csv(
        os.path.join(output_dir, f"{cwid}.csv"),
        index=False
    )

print(f"✅ Raw FOI files saved to: {output_dir}")