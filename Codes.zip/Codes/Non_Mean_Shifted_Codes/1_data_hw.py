import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import re
import sys
import subprocess
import os

plt.rcParams.update({
    'font.size': 14,
    'axes.titlesize': 15,
    'axes.labelsize': 15,
    'xtick.labelsize': 13,
    'ytick.labelsize': 13,
    'legend.fontsize': 13
})

# NEW: Added new parameters for the individual data plot filenames
def process_csv(input_file, cleaned_output, removed_output, average_output, scatter_output, log_scatter_output, yIntercept_output, individual_scatter_output, individual_log_scatter_output):
    # Read CSV file
    df = pd.read_csv(input_file)
    # Ensure at least 4 columns exist
    if df.shape[1] < 4:
        raise ValueError("CSV must have at least 4 columns (timestamp, name, id, and data columns).")

    # Identify rows with at least 5 missing values in data columns (excluding first three columns)
    data_columns = df.columns[5:]
    missing_rows = df[df[data_columns].isnull().sum(axis=1) >= 5].copy()
    missing_rows["Reason"] = "Missing Values"

    # Identify rows where any value (excluding first three columns) is greater than 200
    # Select the columns starting from the fourth one
    cols_to_check = df.columns[3:]

    # Convert those columns to a numeric type, coercing errors
    df[cols_to_check] = df[cols_to_check].apply(pd.to_numeric, errors='coerce')

    # Now, perform your comparison and selection
    high_value_rows = df[(df[cols_to_check] > 180).any(axis=1)].copy()
    
    # Combine both conditions for removal
    removed_rows = pd.concat([missing_rows, high_value_rows]).drop_duplicates()

    # Save removed rows to another file
    removed_rows.to_csv(removed_output, index=False)

    # Remove these rows from the dataset
    cleaned_df = df.drop(removed_rows.index)

    # Calculate the mean of each column (excluding first three columns
    avg_values = cleaned_df.iloc[:, 3:].mean()

    # Create a new row with 'Average' in the name column and mean values in data columns
    avg_row = pd.DataFrame([['Average'] + [''] + [''] + avg_values.tolist()], columns=df.columns)

    # Append the average row to the cleaned data
    cleaned_df_with_avg = pd.concat([cleaned_df, avg_row], ignore_index=True)

    # Save cleaned data with average row to CSV
    cleaned_df_with_avg.to_csv(cleaned_output, index=False)

    # Identify FOI and Time average columns based on alternating patter
    foi_columns = cleaned_df.columns[3::2]
    time_columns = cleaned_df.columns[4::2]

    # Compute FOI and Time averages
    foi_averages = cleaned_df[foi_columns].mean()
    time_averages = cleaned_df[time_columns].mean()
    log_time_averages = np.log(time_averages)

    # Sort columns to ensure Q1 FOI, Q1 Time, Q2 FOI, Q2 Time order
    def extract_number(col_name):
        match = re.search(r'\d+', col_name)
        return int(match.group()) if match else float('inf')
    sorted_columns = sorted(zip(foi_columns, time_columns), key=lambda x: int(re.search(r'\d+', x[0]).group()))

    # Organize averages in correct order and save in column format
    average_df = pd.DataFrame({
        'Questions': [f'Q{i+1}' for i in range(len(sorted_columns))],
        'FOI Average': [foi_averages[col] for col, _ in sorted_columns],
        'Time Average': [time_averages[col] for _, col in sorted_columns],
        'ln(Time Average)': [log_time_averages[col] for _, col in sorted_columns]
    })

    # Compute the overall average of FOI averages and sum of time averages
    overall_foi_avg = foi_averages.mean()
    overall_time_sum = time_averages.sum()

    # Append these as a new row in the CSV file
    total_row = pd.DataFrame({
        'Questions': ['Avg and Sum'],
        'FOI Average': [overall_foi_avg],
        'Time Average': [overall_time_sum],
        'ln(Time Average)': ['']
    })

    average_df = pd.concat([average_df, total_row], ignore_index=True)

    # Ensure correct column order before saving
    column_order = ['Questions', 'FOI Average', 'Time Average', 'ln(Time Average)']
    average_df = average_df[column_order]

    # Save to a new CSV file
    average_df.to_csv(average_output, index=False)

    print(f"Processing complete. Cleaned data saved to {cleaned_output}, removed rows saved to {removed_output}, and averages saved to {average_output}.")

    # --- Original Plots Based on Averages ---
    
    # Prepare for trendline calculations
    min_foi = foi_averages.min()
    max_foi = foi_averages.max()
    trendline_x = np.linspace(min_foi, max_foi, 100)

    # Scatter plot with exponential trendline
    plt.figure(figsize=(10, 6))
    plt.scatter(foi_averages, time_averages, facecolors='none', edgecolors='blue', marker='o', label='Time (Avg by Question)')
    plt.xlim(0, 5)  # Keep FOI axis from 0 to 5
    y_max = int((time_averages.max() + 4) // 5 * 5)  # round to nearest 5 above
    plt.yticks(np.arange(0, y_max + 5, 5))
    

    coefficients = np.polyfit(foi_averages, np.log(time_averages), 1)
    trendline_y = np.exp(coefficients[1]) * np.exp(coefficients[0] * trendline_x)
    equation_label = f"{np.exp(coefficients[1]):.3f}e^({coefficients[0]:.3f}x)"

    plt.plot(trendline_x, trendline_y, color='red', linestyle='-', linewidth=1, label=equation_label)
    plt.xlabel('FOI')
    plt.ylabel('TIME')
    plt.title('FOI vs TIME (Averages per Question)\n\n', loc='left')
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.08), frameon=False, ncol=2)
    plt.savefig(scatter_output)
    plt.close() # Close plot to free memory

    # Scatter plot with ln(Time) for linear relationship
    plt.figure(figsize=(10, 6))
    plt.scatter(foi_averages, log_time_averages, facecolors='none', edgecolors='green', marker='o', label='Time (Avg by Question)')

    plt.xlim(0, 5)  # Keep FOI axis from 0 to 5
    y_max_ln = np.ceil(log_time_averages.max())
    plt.yticks(np.arange(0, y_max_ln + 1.5, 0.5))
    

    lin_coefficients = np.polyfit(foi_averages, log_time_averages, 1)
    lin_trendline_y = lin_coefficients[1] + lin_coefficients[0] * trendline_x
    lin_equation_label = f"{lin_coefficients[1]:.3f} + {lin_coefficients[0]:.3f}x"

    plt.plot(trendline_x, lin_trendline_y, color='red', linestyle='-', linewidth=1, label=lin_equation_label)
    plt.xlabel('FOI')
    plt.ylabel('ln(TIME)')
    plt.title('FOI vs LN(TIME) (Averages per Question)\n\n', loc='left')
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.08), frameon=False, ncol=2)
    plt.savefig(log_scatter_output)
    plt.close() # Close plot

    # Y-Intercept calculation and plot
    y_intercept = np.exp(lin_coefficients[1])
    plt.figure(figsize=(10, 6))
    plt.axhline(y_intercept, color='gray', linestyle='dashed', linewidth=1)
    plt.scatter(0, y_intercept, color='red', marker='o', s=100, label=f'Y-Intercept: {y_intercept:.3f}')
    plt.annotate(f'({0}, {y_intercept:.3f})', xy=(0, y_intercept), xytext=(-1.2, y_intercept + 0.5))
    
    plt.xlabel('FOI')
    plt.ylabel('TIME')
    plt.xlim(0, 5)  # Keep FOI axis from 0 to 5
    y_max = int((y_intercept + 4) // 5 * 5)
    plt.yticks(np.arange(0, y_max + 5, 5))
    plt.ylim(0, y_max + 5)
    plt.title('Y-Intercept Plot', loc='left')
    plt.legend()
    plt.savefig(yIntercept_output)
    plt.close()

    # --- NEW: Plots for Individual Data Points ---
    print("Generating plots for individual data points...")

    # Get all individual FOI and Time values by flattening the DataFrame
    all_foi_values = cleaned_df[foi_columns].values.flatten()
    all_time_values = cleaned_df[time_columns].values.flatten()

    # Remove any potential NaN values from the flattened arrays
    valid_indices = ~np.isnan(all_foi_values) & ~np.isnan(all_time_values)
    all_foi_values = all_foi_values[valid_indices]
    all_time_values = all_time_values[valid_indices]
    
    # Scatter plot of individual data with the same exponential trendline
    plt.figure(figsize=(10, 6))
    plt.scatter(all_foi_values, all_time_values, facecolors='none', edgecolors='blue', marker='o', alpha=0.5, label='Individual Data')
    
    plt.xlim(-0.5, 5.5)
    y_max_individual = int((np.max(all_time_values) + 4) // 5 * 5)
    plt.yticks(np.arange(0, y_max_individual + 5, 5))
    plt.ylim(0, y_max_individual + 5)
    
    plt.xlabel('FOI')
    plt.ylabel('TIME')
    plt.title('Individual FOI vs TIME\n\n', loc='left')
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.08), frameon=False, ncol=2)
    plt.savefig(individual_scatter_output)
    plt.close()

    # Scatter plot of individual ln(Time) data
    log_all_time_values = np.log(all_time_values)
    plt.figure(figsize=(10, 6))
    plt.scatter(all_foi_values, log_all_time_values, facecolors='none', edgecolors='green', marker='o', alpha=0.5, label='Individual Data')

    plt.xlim(-0.5, 5.5)
    y_max_ln_individual = np.ceil(np.max(log_all_time_values))
    plt.yticks(np.arange(0, y_max_ln_individual + 1.5, 0.5))
    plt.ylim(0, y_max_ln_individual + 0.5)
    
    plt.xlabel('FOI')
    plt.ylabel('ln(TIME)')
    plt.title('Individual FOI vs LN(TIME)\n\n', loc='left')
    plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.08), frameon=False, ncol=2)
    plt.savefig(individual_log_scatter_output)
    plt.close()
    
    print(f"Individual data plots saved to {individual_scatter_output} and {individual_log_scatter_output}")


if __name__ == "__main__":
    while 1 == 1 :
        hw_number = input("Enter the HW number (e.g., HW1, HW2): ")
        if hw_number == 'done':
          #  subprocess.run(["python", "2_individual_Time_FOI.py"])
            sys.exit()
        base_path = f"/home/ajfla/TIMEFOIPROJECT/Physics_Of_Education_Compiled_Data/Lin_PH106_F2024/TIMEFOI_Survey/{hw_number}PH106F24_raw"

        use_default = input(f"Do you want to use the default path ({base_path}.csv)? (yes/no): ").strip().lower()

        if use_default == 'yes':
            input_csv = f"{base_path}.csv"
        else:
            input_csv = input("Enter the path for the input CSV file: ")

        # Original output file paths
        output_csv = f"{base_path}/{hw_number}PH106_processed_output.csv"
        removed_rows_csv = f"{base_path}/{hw_number}PH106_removed_rows.csv"
        average_output = f"{base_path}/{hw_number}PH106_TimeFOI_averages.csv"
        scatter_output = f"{base_path}/{hw_number}PH106_scatter_plot.png"
        log_scatter_output = f"{base_path}/{hw_number}PH106_LN_scatter_plot.png"
        yIntercept_output = f"{base_path}/{hw_number}PH106_yIntercept_plot.png"

        # NEW: Define file paths for the new individual plots
        individual_scatter_output = f"{base_path}/{hw_number}PH106_individual_scatter_plot.png"
        individual_log_scatter_output = f"{base_path}/{hw_number}PH106_individual_LN_scatter_plot.png"

        if not os.path.exists(base_path):
            os.makedirs(base_path)

    # NEW: Pass the new file paths to the processing function
        process_csv(
            input_csv, 
            output_csv, 
            removed_rows_csv, 
            average_output, 
            scatter_output, 
            log_scatter_output, 
            yIntercept_output,
            individual_scatter_output,
            individual_log_scatter_output
        )