import os
import pandas as pd
import numpy as np
import re
from collections import Counter
from plotly.subplots import make_subplots
import plotly.graph_objects as go
from scipy.stats import poisson, chisquare, norm
from pathlib import Path
import base64

# --- CONFIG --- #
main_folder = Path("/home/ajfla/TIMEFOIPROJECT/LinResearchData/AY206_S2026/Raw_Data")

# Directory for Time/FOI data
input_dir = main_folder 

# NEW: Directory for Correctness CSVs (Coder can edit this path)
correctness_dir = main_folder 

# NEW: Output directories
base_output_dir = main_folder / "test_individual"
base_csv_output_dir = base_output_dir / "test_individual_csv_files_for_graphs"
CWID_LOOKUP_FILE = base_output_dir / "test_individual_cwid_lookup_table.csv"

base_output_dir.mkdir(parents=True, exist_ok=True)
base_csv_output_dir.mkdir(parents=True, exist_ok=True)

# Custom grayscale for the heatmap
custom_greyscale = [
    [0.0, "#D9D9D9"],  # Light gray
    [1.0, "#000000"]   # Black
]

# --- Simple Encoding Function ---
def encode_cwid_simple(cwid):
    """Simply encodes a CWID using Base64. NOT CRYPTOGRAPHICALLY SECURE."""
    return base64.urlsafe_b64encode(str(cwid).encode('utf-8')).decode('utf-8').rstrip('=')

# --- CWID Mapping Management ---
def load_cwid_lookup(file_path):
    if file_path.exists():
        try:
            df = pd.read_csv(file_path)
            return dict(zip(df['Original_CWID'], df['Encoded_CWID']))
        except pd.errors.EmptyDataError:
            return {}
    return {}

def save_cwid_lookup(mapping, file_path):
    df = pd.DataFrame(list(mapping.items()), columns=['Original_CWID', 'Encoded_CWID'])
    df.to_csv(file_path, index=False)

cwid_mapping = load_cwid_lookup(CWID_LOOKUP_FILE)

# --- Helper functions ---
def create_page_layout_html(title, plot_div, sidebar_html_content):
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>{title}</title>
        <style>
            body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;margin:0;background-color:#f8f9fa}}
            .header{{padding:1em 2em;background-color:white;border-bottom:1px solid #dee2e6; box-shadow: 0 2px 4px rgba(0,0,0,0.05);}}
            h1{{color:#333; font-size: 1.8em; margin: 0;}}
            .container{{display:flex;height:calc(100vh - 75px)}}
            .plot-area{{flex:3; padding:1em; overflow-y: auto; background-color: #ffffff; border-radius: 8px; margin: 1em; box-shadow: 0 2px 5px rgba(0,0,0,0.1); min-height: 1000px;}}
            .sidebar{{flex:1;padding:1em;border-left:1px solid #dee2e6;background-color:white; border-radius: 8px; margin: 1em; box-shadow: 0 2px 5px rgba(0,0,0,0.1);}}
            .sidebar h2{{font-size:1.2em;border-bottom:2px solid #dee2e6;padding-bottom:0.5em;margin-top:1em; color: #555;}}
            .stats-block {{margin-bottom: 1.5em;}}
            .stats-block h2{{font-size:1.1em;border-bottom:1px solid #ccc;padding-bottom:0.3em;margin-top:1em; color: #666;}}
            .stats-block table{{width:100%;border-collapse:collapse;margin-top:0.5em;font-size:0.85em; border: 1px solid #e0e0e0; border-radius: 5px; overflow: hidden;}}
            .stats-block th, .stats-block td{{text-align:left;padding:10px;border-bottom:1px solid #e0e0e0;}}
            .stats-block th{{background-color:#f8f8f8;font-weight:600; color: #444;}}
            .stats-block tr:nth-child(even) {{background-color: #f3f3f3;}}
            .stats-block tr:hover {{background-color: #e9e9e9;}}
            .no-grades-banner {{
                background-color: #fff3cd; border: 1px solid #ffc107;
                border-radius: 6px; padding: 10px 14px;
                font-size: 0.85em; color: #856404; margin-bottom: 1em;
            }}
            .plot-area .plotly-graph-div {{ height: auto !important; min-height: 100%; }}
        </style>
    </head>
    <body>
        <div class="header"><h1>{title}</h1></div>
        <div class="container">
            <div class="plot-area">{plot_div}</div>
            <div class="sidebar">{sidebar_html_content}</div>
        </div>
    </body>
    </html>
    """

def create_sidebar_html(stats_html_block, has_grades):
    grade_notice = ""
    if not has_grades:
        grade_notice = (
            '<div class="no-grades-banner">'
            '&#9888; No correctness file found for this student. '
            'Grade coloring and threshold controls are hidden.'
            '</div>'
        )
    return f"<h2>Analysis Tables</h2>{grade_notice}{stats_html_block}"

def get_q_pairs(df):
    foi_cols = sorted([c for c in df.columns if "FOI" in c and re.search(r"Q\d+", c)], key=lambda x: int(re.search(r"Q(\d+)", x).group(1)))
    time_cols = sorted([c for c in df.columns if "TIME" in c and re.search(r"Q\d+", c)], key=lambda x: int(re.search(r"Q(\d+)", x).group(1)))
    return list(zip(foi_cols, time_cols))

# --- Pass 1: Identifying all students and their data ---
print("Pass 1: Identifying all students and linking grades...")
all_student_data_meta = []

for filename in os.listdir(input_dir):
    if not filename.endswith(".csv"):
        continue
    original_cwid = os.path.splitext(filename)[0]

    # Skip the CWID lookup table itself if it landed in the same folder
    if original_cwid == CWID_LOOKUP_FILE.stem:
        continue

    if original_cwid not in cwid_mapping:
        encoded_cwid = encode_cwid_simple(original_cwid)
        cwid_mapping[original_cwid] = encoded_cwid
    else:
        encoded_cwid = cwid_mapping[original_cwid]

    student_name_for_output = encoded_cwid
    student_csv_dir = base_csv_output_dir / student_name_for_output
    os.makedirs(student_csv_dir, exist_ok=True)
    student_report_output_dir = base_output_dir / student_name_for_output
    os.makedirs(student_report_output_dir, exist_ok=True)

    # --- Load Correctness Data for this Student ---
    grade_map = {}
    correctness_file = correctness_dir / f"{original_cwid}_correctness.csv"
    if correctness_file.exists():
        try:
            df_corr = pd.read_csv(correctness_file)
            for _, row in df_corr.iterrows():
                if pd.isna(row.get('HW')):
                    continue
                hw_val = str(row['HW']).strip()
                for col in df_corr.columns:
                    if col.startswith('Q') and pd.notna(row[col]):
                        try:
                            q_n = int(re.search(r"Q(\d+)", col).group(1))
                            grade_map[(hw_val, q_n)] = float(row[col])
                        except (ValueError, AttributeError):
                            pass
        except Exception as e:
            print(f"Error reading correctness for {original_cwid}: {e}")
    else:
        print(f"  [INFO] No correctness file found for {original_cwid} — grade coloring disabled.")
    
    try:
        df = pd.read_csv(os.path.join(input_dir, filename))
        if "HW" not in df.columns:
            continue
            
        records = []
        for _, row in df.iterrows():
            hw_val = str(row['HW']).strip() if 'HW' in row else "Unknown"
            for foi_col, time_col in get_q_pairs(row.to_frame().T):
                try:
                    q_num = int(re.search(r"Q(\d+)", foi_col).group(1))
                    foi = float(row[foi_col])
                    time = float(row[time_col])
                    
                    # Fetch Grade (np.nan when no correctness file)
                    grade = grade_map.get((hw_val, q_num), np.nan)

                    if 0 <= foi <= 5 and 0 < time <= 1000:
                        records.append((foi, time, "MCQ" if q_num <= 11 else "Non-MCQ", q_num, grade, hw_val))
                except (ValueError, TypeError):
                    continue

        if not records:
            continue

        df_plot = pd.DataFrame(records, columns=["FOI", "Time", "Type", "Q", "Grade", "HW"])

        # Determine whether any real grade data exists for this student
        has_grades = df_plot['Grade'].notna().any()
        
        all_student_data_meta.append({
            'name': student_name_for_output,
            'html_path': f"{student_name_for_output}_full_report.html",
            'df_plot': df_plot,
            'has_grades': has_grades,
        })

        main_plot_csv_filename = f"{student_name_for_output}_main_plot_data.csv"
        df_plot.to_csv(student_csv_dir / main_plot_csv_filename, index=False)

    except Exception as e:
        print(f"Could not process {filename}: {e}")

save_cwid_lookup(cwid_mapping, CWID_LOOKUP_FILE)
all_student_data_meta.sort(key=lambda x: x['name'])
print(f"Pass 1 complete. Found {len(all_student_data_meta)} valid files.")

# --- Helper Function for dynamic coloring based on Toggle Logic ---
def get_colors(df_sub, threshold, hide_red=False, hide_green=False, has_grades=True):
    """
    Returns a color list for scatter markers.
    - If has_grades is False, all points are rendered in a neutral blue-gray
      (no grade-based coloring, no slider/button logic needed).
    - Otherwise, green = grade >= threshold, red = grade < threshold, gray = no grade.
    """
    if not has_grades:
        return ['#6c8ebf'] * len(df_sub)  # neutral blue-gray for all points

    colors = []
    for g in df_sub['Grade']:
        if pd.notna(g) and g >= threshold:
            colors.append('rgba(0,0,0,0)' if hide_green else 'green')
        elif pd.isna(g):
            colors.append('gray')
        else:
            colors.append('rgba(0,0,0,0)' if hide_red else 'red')
    return colors

# --- PASS 2: Generate detailed reports ---
print("\nPass 2: Generating sorted HTML reports with Grade Sliders...")
for student_meta in all_student_data_meta:
    df_plot = student_meta['df_plot']
    student_name_for_output = student_meta['name']
    has_grades = student_meta['has_grades']

    student_csv_dir = base_csv_output_dir / student_name_for_output
    os.makedirs(student_csv_dir, exist_ok=True)
    student_report_output_dir = base_output_dir / student_name_for_output
    os.makedirs(student_report_output_dir, exist_ok=True)

    # --- Analysis Tables ---
    table1_html = '<div class="stats-block"><h2>Continuous Analysis</h2><table><tr><th>FOI</th><th># Qs</th><th>Mean</th><th>Variance</th></tr>'
    table2_html = '<div class="stats-block"><h2>Binned Analysis</h2><table><tr><th>FOI</th><th># Qs</th><th>Binned Mean Time</th><th>Binned Variance</th></tr>'

    time_bin_size = 2
    global_bins = np.arange(0, 70 + time_bin_size, time_bin_size)
    time_hist_bins_for_plot = np.arange(0, 71, time_bin_size)

    for foi_level in np.arange(0, 6):
        foi_df = df_plot[(df_plot['FOI'] >= foi_level - 0.5) & (df_plot['FOI'] < foi_level + 0.5)]
        
        if not foi_df.empty:
            counts, bin_edges = np.histogram(foi_df['Time'], bins=time_hist_bins_for_plot)
            total_observations = counts.sum()
            probabilities = counts / total_observations if total_observations > 0 else np.zeros_like(counts, dtype=float)
            histogram_data_for_csv = pd.DataFrame({'Bin_Start': bin_edges[:-1], 'Bin_End': bin_edges[1:], 'Count': counts, 'Probability': probabilities})
        else:
            histogram_data_for_csv = pd.DataFrame({'Bin_Start': time_hist_bins_for_plot[:-1], 'Bin_End': time_hist_bins_for_plot[1:], 'Count': np.zeros(len(time_hist_bins_for_plot) - 1, dtype=int), 'Probability': np.zeros(len(time_hist_bins_for_plot) - 1, dtype=float)})

        histogram_csv_filename = f"FOI_{foi_level}_histogram_data.csv"
        histogram_data_for_csv.to_csv(student_csv_dir / histogram_csv_filename, index=False)

        if len(foi_df) < 2:
            table1_html += f"<tr><td>{foi_level}</td><td colspan='3'><i>Not enough data</i></td></tr>"
            table2_html += f"<tr><td>{foi_level}</td><td colspan='3'><i>Not enough data</i></td></tr>"
        else:
            num_questions = len(foi_df)
            mean_time = foi_df['Time'].mean()
            variance_time = foi_df['Time'].var(ddof=1)
            counts_in_bins, _ = np.histogram(foi_df['Time'], bins=global_bins)
            total_questions_in_bins = np.sum(counts_in_bins)
            binned_mean_time = np.sum(counts_in_bins * ((global_bins[:-1] + global_bins[1:]) / 2)) / total_questions_in_bins if total_questions_in_bins > 0 else 0
            weighted_avg_variance = np.sum(counts_in_bins * (((global_bins[:-1] + global_bins[1:]) / 2) - binned_mean_time)**2) / (total_questions_in_bins - 1) if total_questions_in_bins > 1 else 0

            table1_html += f"<tr><td>{foi_level}</td><td>{num_questions}</td><td>{mean_time:.2f}</td><td>{variance_time:.2f}</td></tr>"
            table2_html += f"<tr><td>{foi_level}</td><td>{num_questions}</td><td>{binned_mean_time:.2f}</td><td>{weighted_avg_variance:.2f}</td></tr>"

    table1_html += "</table></div>"
    table2_html += "</table></div>"
    full_stats_block = table1_html + table2_html

    # --- Create the Main Plot ---
    fig_main = go.Figure()
    y_max_plot_main = int((df_plot["Time"].max() + 9) // 10 * 10) if not df_plot.empty else 30
    x_bins_heatmap = np.linspace(0, 5, 50)
    y_bins_heatmap = np.linspace(0, y_max_plot_main + 2)
    heatmap_data, _, _ = np.histogram2d(df_plot["FOI"], df_plot["Time"], bins=[x_bins_heatmap, y_bins_heatmap])
    
    # Trace 0: Heatmap
    fig_main.add_trace(go.Heatmap(
        z=np.where(heatmap_data.T == 0, None, heatmap_data.T),
        x=x_bins_heatmap, y=y_bins_heatmap, colorscale=custom_greyscale,
        colorbar=dict(title='Density'), name="Density", legendgroup="Density",
        showlegend=True, hovertemplate='FOI: %{x:.2f}<br>Time: %{y:.2f}<br>Count: %{z}<extra></extra>', opacity=0.6
    ))

    mcq = df_plot[df_plot["Type"] == "MCQ"]
    nm  = df_plot[df_plot["Type"] == "Non-MCQ"]
    
    traces_to_update = []

    # Pre-compute color configs only when grade data exists
    default_slider_val = 5
    if has_grades:
        color_configs = {
            'all':      {i: [] for i in range(11)},
            'no_red':   {i: [] for i in range(11)},
            'no_green': {i: [] for i in range(11)},
        }

    trace_idx = 1  # Heatmap occupies index 0

    for subset, label, symbol in [(mcq, "MCQ", 'circle'), (nm, "Non-MCQ", 'triangle-up')]:
        if subset.empty:
            continue

        marker_color = get_colors(subset, default_slider_val, has_grades=has_grades)

        fig_main.add_trace(go.Scatter(
            x=subset["FOI"], y=subset["Time"], mode='markers',
            name=label, legendgroup=label,
            marker=dict(symbol=symbol, size=9 if label == "MCQ" else 10,
                        line=dict(width=0), color=marker_color),
            hovertemplate=(
                'HW: %{customdata[2]}<br>Q: %{customdata[0]}<br>'
                + ('Grade: %{customdata[1]}<br>' if has_grades else '')
                + 'FOI: %{x}<br>Time: %{y}<br>Type: ' + label + '<extra></extra>'
            ),
            customdata=subset[['Q', 'Grade', 'HW']].values,
            showlegend=True
        ))
        traces_to_update.append(trace_idx)

        if has_grades:
            for i in range(11):
                color_configs['all'][i].append(get_colors(subset, i, has_grades=True))
                color_configs['no_red'][i].append(get_colors(subset, i, hide_red=True, has_grades=True))
                color_configs['no_green'][i].append(get_colors(subset, i, hide_green=True, has_grades=True))

        trace_idx += 1

    # Grade slider and buttons — only when grade data is present
    sliders = []
    updatemenus = []

    if has_grades and traces_to_update:
        slider_steps = [
            dict(
                method="restyle",
                args=[{"marker.color": color_configs['all'][v]}, traces_to_update],
                label=str(v)
            )
            for v in range(11)
        ]
        sliders = [dict(
            active=default_slider_val,
            currentvalue={"prefix": "Grade Threshold: "},
            pad={"t": 0, "r": 10},
            x=0.55, y=1.1, len=0.25,
            xanchor="left", yanchor="top",
            steps=slider_steps,
            ticklen=0, minorticklen=0
        )]

        updatemenus = [dict(
            type="buttons", direction="right",
            x=0.82, y=1.08, xanchor="left", yanchor="top", showactive=True,
            buttons=[
                dict(label="Show Both",  method="restyle", args=[{"marker.color": color_configs['all'][default_slider_val]},      traces_to_update]),
                dict(label="Hide Red",   method="restyle", args=[{"marker.color": color_configs['no_red'][default_slider_val]},   traces_to_update]),
                dict(label="Hide Green", method="restyle", args=[{"marker.color": color_configs['no_green'][default_slider_val]}, traces_to_update]),
            ]
        )]

    fig_main.update_layout(
        title_text=f"Individual HW FOI vs. Time: {student_name_for_output}",
        height=600, width=800, plot_bgcolor="white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.25),
        sliders=sliders,
        updatemenus=updatemenus,
        hovermode="closest", margin=dict(l=60, r=60, t=90, b=60), title_font_size=16
    )
    
    fig_main.update_xaxes(title_text="Freak Out Index (FOI)", range=[-3.5, 3.5], tickmode='array', tickvals=np.arange(0, 6), showline=True, mirror=True, linecolor='black', showgrid=False)
    fig_main.update_yaxes(title_text="Time (minutes)", range=[0, min(y_max_plot_main + 10, 48)], showline=True, mirror=True, linecolor='black', showgrid=False)

    plot_div_main = fig_main.to_html(full_html=False, include_plotlyjs='cdn')

    # --- Create the 6 Histograms ---
    fig_histograms = make_subplots(rows=6, cols=1, subplot_titles=[f"Time Distribution for FOI = {i}" for i in np.arange(0, 6)], vertical_spacing=0.08)
    time_hist_bins_for_plot = np.arange(0, 71, 2)

    max_y_value_count, max_y_value_prob = 0, 0
    for foi_level in np.arange(0, 6):
        foi_specific_df = df_plot[(df_plot['FOI'] >= foi_level - 0.5) & (df_plot['FOI'] < foi_level + 0.5)]
        if not foi_specific_df.empty:
            counts, _ = np.histogram(foi_specific_df['Time'], bins=time_hist_bins_for_plot)
            max_y_value_count = max(counts.max(), max_y_value_count)
            total_observations = counts.sum()
            if total_observations > 0:
                max_y_value_prob = max((counts / total_observations).max(), max_y_value_prob)

    y_axis_updates_counts, y_axis_updates_probs = {}, {}
    for j in range(6):
        y_axis_updates_counts.update({f'yaxis{j+1}.title.text': 'Counts',      f'yaxis{j+1}.range': [0, max_y_value_count * 1.1]})
        y_axis_updates_probs.update( {f'yaxis{j+1}.title.text': 'Probability', f'yaxis{j+1}.range': [0, max_y_value_prob * 1.1]})

    counts_visible_state, probs_visible_state = [], []
    
    for i, foi_level in enumerate(np.arange(0, 6)):
        foi_specific_df = df_plot[(df_plot['FOI'] >= foi_level - 0.5) & (df_plot['FOI'] < foi_level + 0.5)]
        row_num, col_num = i + 1, 1
        bin_centers_for_plot = (time_hist_bins_for_plot[:-1] + time_hist_bins_for_plot[1:]) / 2

        if foi_specific_df.empty:
            fig_histograms.add_trace(go.Scatter(x=[35], y=[0], mode='text', text=['No data'], textfont=dict(size=18, color="gray"), showlegend=False, hoverinfo='none'), row=row_num, col=col_num)
            for _ in range(3):
                fig_histograms.add_trace(go.Scatter(visible=False), row=row_num, col=col_num)
            counts_visible_state.extend([True, False, False, False])
            probs_visible_state.extend([True, False, False, False])
        else:
            counts_for_bar, _ = np.histogram(foi_specific_df['Time'], bins=time_hist_bins_for_plot)
            total_obs_in_foi = counts_for_bar.sum()
            probabilities_for_bar = counts_for_bar / total_obs_in_foi if total_obs_in_foi > 0 else np.zeros_like(counts_for_bar)

            fig_histograms.add_trace(go.Bar(x=bin_centers_for_plot, y=counts_for_bar, width=2, marker_color='skyblue', hovertemplate='Time Bin: %{x}<br>Count: %{y}<extra></extra>', showlegend=False), row=row_num, col=col_num)
            fig_histograms.add_trace(go.Scatter(x=bin_centers_for_plot, y=counts_for_bar, mode='lines+markers', line=dict(color='darkblue', width=2, dash='dot'), hovertemplate='Time Bin: %{x}<br>Count: %{y}<extra></extra>', showlegend=False), row=row_num, col=col_num)
            fig_histograms.add_trace(go.Bar(x=bin_centers_for_plot, y=probabilities_for_bar, width=2, marker_color='lightcoral', hovertemplate='Time Bin: %{x}<br>Probability: %{y:.4f}<extra></extra>', showlegend=False), row=row_num, col=col_num)
            fig_histograms.add_trace(go.Scatter(x=bin_centers_for_plot, y=probabilities_for_bar, mode='lines+markers', line=dict(color='red', width=2, dash='dot'), hovertemplate='Time Bin: %{x}<br>Probability: %{y:.4f}<extra></extra>', showlegend=False), row=row_num, col=col_num)
            
            counts_visible_state.extend([True,  True,  False, False])
            probs_visible_state.extend( [False, False,  True,  True])

    fig_histograms.update_xaxes(title_text="Time Bins (minutes)", range=[-0.5, 70.5], tickmode='array', tickvals=np.arange(0, 71, 10), showline=True, mirror=True, linecolor='black', showgrid=False)
    fig_histograms.update_yaxes(showline=True, mirror=True, linecolor='black', showgrid=False)

    fig_histograms.update_layout(
        height=300 * 6, width=800, plot_bgcolor="white", paper_bgcolor="white",
        margin=dict(l=60, r=60, t=90, b=60), barmode='overlay',
        updatemenus=[go.layout.Updatemenu(
            type="buttons", direction="right", x=0.01, y=1.08, xanchor="left", yanchor="top", active=0,
            buttons=[
                dict(label="Counts",      method="update", args=[{"visible": counts_visible_state}, y_axis_updates_counts]),
                dict(label="Probability", method="update", args=[{"visible": probs_visible_state},  y_axis_updates_probs])
            ]
        )]
    )

    plot_div_histograms = fig_histograms.to_html(full_html=False, include_plotlyjs='cdn')

    combined_plot_div = f"<div>{plot_div_main}</div><br><h2>Individual FOI Time Distributions</h2><br><div>{plot_div_histograms}</div>"
    sidebar_html_content = create_sidebar_html(full_stats_block, has_grades)
    html_output_path = student_report_output_dir / student_meta['html_path']
    full_html = create_page_layout_html(f"Analysis for: {student_name_for_output}", combined_plot_div, sidebar_html_content)
    with open(html_output_path, "w", encoding="utf-8") as f:
        f.write(full_html)
    print(f"Generated report for '{student_name_for_output}' at {html_output_path}")

# --- Generate the main index HTML file ---
print("\n--- Generating main index HTML file ---")
index_html_path = base_output_dir / 'index.html'

with open(index_html_path, 'w') as f:
    f.write('<!DOCTYPE html>\n<html lang="en">\n<head>\n')
    f.write('    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n')
    f.write(f'    <title>Individual Student Reports (Correctness)</title>\n')
    f.write('    <style>\n        html, body { margin: 0; padding: 0; height: 100%; }\n        body { font-family: Arial, sans-serif; overflow: hidden; display: flex; }\n        .sidebar { width: 250px; overflow-y: auto; padding: 20px; background-color: #f8f9fa; border-right: 1px solid #e9ecef; }\n        .main-content { flex-grow: 1; display: flex; flex-direction: column; }\n        h1, h2 { color: #333; text-align: center; margin-top: 10px; }\n        .student-list { list-style: none; padding: 0; }\n        .student-list li { margin-bottom: 5px; }\n        .student-list a { text-decoration: none; color: #007bff; padding: 8px 12px; display: block; border-radius: 4px; transition: background-color 0.2s ease-in-out; }\n        .student-list a:hover { background-color: #e2e6ea; color: #0056b3; }\n        iframe { width: 100%; height: 100%; border: none; }\n        .intro-container { display: flex; justify-content: center; align-items: center; height: 100%; }\n        .intro-message { text-align: center; color: #666; }\n    </style>\n</head>\n<body>\n')
    f.write('    <div class="sidebar">\n        <h2>Student ID</h2>\n        <ul class="student-list">\n')
    
    for student_meta in all_student_data_meta:
        report_relative_path = Path(student_meta['name']) / student_meta['html_path']
        grade_indicator = "" if student_meta['has_grades'] else " &#9888;"  # warning symbol for no-grade students
        f.write(f'            <li><a href="./{report_relative_path}" target="student_report_frame" title="{"Grade data available" if student_meta["has_grades"] else "No grade data"}">{student_meta["name"]}{grade_indicator}</a></li>\n')
    
    f.write('        </ul>\n    </div>\n    <div class="main-content">\n        <iframe name="student_report_frame" id="student_report_frame" src="about:blank"></iframe>\n    </div>\n')
    f.write('<script>\n    const iframe = document.getElementById("student_report_frame");\n')
    f.write('    const welcomeMessage = `\n        <div class="intro-container">\n            <div class="intro-message">\n                <h1>Analysis Reports with Grades</h1>\n                <p>Select a student from the list on the left to view their report.</p>\n                <p style="color:#856404; font-size:0.9em;">&#9888; = no correctness file found for that student.</p>\n            </div>\n        </div>\n    `;\n')
    f.write('    iframe.contentWindow.document.open();\n    iframe.contentWindow.document.write(welcomeMessage);\n    iframe.contentWindow.document.close();\n</script>\n</body>\n</html>\n')

print("Script finished.")