import pandas as pd
import re
from pathlib import Path

# --- CONFIG ---
# Path to your main research folder
main_folder = Path("/home/ajfla/TIMEFOIPROJECT/Codes/Codes_Updated/Codes/Onboarding_Data/LIN_PH106_F2025")

# 1. Directory where the "HW*_Correctness.xlsx" files are stored
homework_grades_dir = main_folder / "Correctness"

# 2. Directory where the individual correctness CSVs will be saved
output_dir = main_folder / "Individual_Correctness"

# Create output directory if it doesn't exist
output_dir.mkdir(parents=True, exist_ok=True)

def main():
    # dictionary to store data per student: {cwid: [list of homework records]}
    student_data_map = {}

    # 1. Scan for all homework grade files
    print(f"Scanning for homework files in: {homework_grades_dir}")
    
    if not homework_grades_dir.exists():
        print(f"Error: Directory {homework_grades_dir} not found. Please check your path.")
        return

    # Look for Excel homework files
    hw_files = sorted(list(homework_grades_dir.glob("HW*Correctness.xlsx")))
    
    if not hw_files:
        print("No homework grade files found. Ensure they are named like 'HW10Correctness.xlsx'.")
        
        # Check if they are just in the main folder instead
        hw_files = sorted(list(main_folder.glob("HW*Correctness.xlsx")))
        
        if hw_files:
            print(f"Found {len(hw_files)} files in main folder instead of /Correctness. Using those.")
        else:
            return

    for file_path in hw_files:
        # Extract HW label (e.g., "HW10") from the filename
        hw_match = re.search(r"HW(\d+)", file_path.name, re.IGNORECASE)
        hw_label = hw_match.group(0).upper() if hw_match else file_path.stem
        
        print(f"Processing {file_path.name}...")
        
        try:
            # Read Excel instead of CSV
            df = pd.read_excel(file_path)
            
            # Clean column names (strip whitespace)
            df.columns = df.columns.str.strip().str.replace(' ', '_')
            
            if 'CWID' not in df.columns:
                print(f"  -> Skipping: 'CWID' column not found.")
                continue

            # Identify all Question columns (Q1, Q2, etc.)
            q_cols = sorted(
                [c for c in df.columns if re.match(r"^Q\d+$", c)],
                key=lambda x: int(re.search(r"\d+", x).group())
            )
            
            for _, row in df.iterrows():
                # Handle CWID formatting
                raw_cwid = str(row['CWID']).split('.')[0].strip()
                
                # Build homework record
                record = {'HW': hw_label}
                for col in q_cols:
                    record[col] = row[col]
                
                if raw_cwid not in student_data_map:
                    student_data_map[raw_cwid] = []
                    
                student_data_map[raw_cwid].append(record)
                
        except Exception as e:
            print(f"  -> Error processing {file_path.name}: {e}")

    # 2. Save individual correctness CSVs
    print(f"\nSaving individual files to: {output_dir}")
    
    count = 0
    
    for cwid, records in student_data_map.items():
        df_student = pd.DataFrame(records)
        
        # Reorder columns
        q_cols_present = [c for c in df_student.columns if c != 'HW']
        
        q_cols_sorted = sorted(
            q_cols_present,
            key=lambda x: int(re.search(r"\d+", x).group()) if re.search(r"\d+", x) else 0
        )
        
        final_cols = ['HW'] + q_cols_sorted
        df_student = df_student[final_cols]
        
        # Output CSV (same as original script)
        output_file = output_dir / f"{cwid}_correctness.csv"
        df_student.to_csv(output_file, index=False)
        
        count += 1

    print("-" * 50)
    print(f"Done! Created correctness CSVs for {count} students.")


if __name__ == "__main__":
    main()