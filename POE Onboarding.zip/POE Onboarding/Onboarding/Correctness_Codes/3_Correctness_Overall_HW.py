import os
from pathlib import Path

# --- CONFIG ---
main_folder = Path("/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinSpring2025PH106/")
GALLERY_BASE_DIR = main_folder / "Gallery" / "Individual_Mean_Shifted_Slided_Gallery"
static_images_dir = GALLERY_BASE_DIR / "static_previews"

# --- HTML STYLE ---
HTML_STYLE = """
<style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f0f2f5; margin: 0; padding: 20px; }
    .page-wrapper { max-width: 1800px; margin: 0 auto; background-color: #ffffff; border-radius: 10px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); padding: 20px 40px; }
    h1 { text-align: center; color: #1c1e21; border-bottom: 2px solid #e7e7e7; padding-bottom: 15px; margin-bottom: 30px; }
    .gallery-container { display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; }
    .gallery-container a { text-decoration: none; color: inherit; flex: 1 1 30%; max-width: 32%; display: flex; }
    .analysis-section { display: flex; flex-direction: column; align-items: center; width: 100%; border: 1px solid #ddd; border-radius: 8px; padding: 15px; background-color: #ffffff; box-shadow: 0 2px 5px rgba(0,0,0,0.05); transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out; }
    .analysis-section img { width: 100%; height: auto; border-radius: 4px; }
    .analysis-section:hover { transform: translateY(-5px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-color: #dc3545; }
    .plot-info { text-align: center; font-weight: 600; margin-top: 12px; color: #333; font-size: 0.95em;}
    @media (max-width: 1600px) { .gallery-container a { max-width: 48%; } }
    @media (max-width: 900px) { .gallery-container a { max-width: 95%; } }
</style>
"""

if __name__ == "__main__":

    print("Building gallery from existing preview images...")

    image_files = sorted(static_images_dir.glob("*_preview.png"))

    output_html_path = GALLERY_BASE_DIR / "correctness_gallery.html"

    html_content = f"<!DOCTYPE html><html><head><title>Student FOI Gallery</title>{HTML_STYLE}</head><body>"
    html_content += '<div class="page-wrapper"><h1>Individual Student FOI vs. Time Gallery</h1>'
    html_content += '<div class="gallery-container">'

    for image_path in image_files:
        student_id = image_path.stem.replace("_preview", "")
        img_url = f"static_previews/{image_path.name}"
        report_url = f"../../test_individual_mean_shifted/{student_id}/{student_id}_full_report.html"

        html_content += f"""
        <a href="{report_url}" target="_blank">
            <div class="analysis-section">
                <img src="{img_url}">
                <div class="plot-info">
                    Student: {student_id}
                </div>
            </div>
        </a>"""

    html_content += "</div></div></body></html>"

    with open(output_html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print(f"SUCCESS: Gallery created at {output_html_path}")