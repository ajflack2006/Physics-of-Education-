import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import re
import subprocess

plt.rcParams.update({
    'font.size': 14,
    'axes.titlesize': 16,
    'axes.labelsize': 15,
    'xtick.labelsize': 13,
    'ytick.labelsize': 13,
    'legend.fontsize': 12
})


def extract_hw_number(folder_name):
    match = re.search(r'\d+', folder_name)
    return int(match.group()) if match else None


def regression_with_se(x, y):
    n = len(x)
    slope, intercept = np.polyfit(x, y, 1)

    y_pred = slope * x + intercept
    residuals = y - y_pred
    s_err = np.sqrt(np.sum(residuals**2) / (n - 2))

    x_mean = np.mean(x)
    Sxx = np.sum((x - x_mean)**2)

    intercept_se = s_err * np.sqrt(1/n + x_mean**2 / Sxx)

    return intercept, intercept_se


def collect_C_values(base_directory):

    records = []

    for folder in os.listdir(base_directory):

        if not folder.startswith("HW"):
            continue

        hw_path = os.path.join(base_directory, folder)

        # ---- Robust file detection ----
        averages_file = None
        for file in os.listdir(hw_path):
            if "TimeFOI_averages" in file and file.endswith(".csv"):
                averages_file = os.path.join(hw_path, file)
                break

        if averages_file is None:
            continue

        df = pd.read_csv(averages_file)
        df = df[df["Questions"] != "Avg and Sum"]

        foi = df["FOI Average"].values
        ln_time = df["ln(Time Average)"].values

        intercept, intercept_se = regression_with_se(foi, ln_time)

        hw_num = extract_hw_number(folder)

        records.append((hw_num, intercept, intercept_se, folder))

    # ---- Sort by actual HW number ----
    records.sort(key=lambda x: x[0])

    # ---- Sequential index 1..N ----
    seq_numbers = np.arange(1, len(records) + 1)

    C_values = np.array([r[1] for r in records])
    C_errors = np.array([r[2] for r in records])
    labels = [r[3] for r in records]

    return seq_numbers, C_values, C_errors, labels


if __name__ == "__main__":

    base_directory = "/home/ajfla/TIMEFOIPROJECT/Codes/Codes_Updated/Codes/Onboarding_Data/LIN_PH106_F2025"

    seq_numbers, C_values, C_errors, labels = collect_C_values(base_directory)

    plt.figure(figsize=(10, 6))

    plt.plot(seq_numbers, C_values, marker='o', label="C values")

    plt.errorbar(
        seq_numbers,
        C_values,
        yerr=1.96 * C_errors,
        fmt='none',
        capsize=4
    )

    plt.xlabel("Homework Index")
    plt.ylabel("C Value (Intercept)")
    plt.title("Intercept (C) Across Homeworks\n\n", loc='left')

    plt.xticks(seq_numbers)   # 1..N spacing

    plt.grid(alpha=0.25)
    plt.legend(frameon=False)

    output_file = os.path.join(
        base_directory,
        "All_Homeworks_C_values_PUBLICATION.png"
    )

    plt.tight_layout()
    plt.savefig(output_file, dpi=300)
    plt.close()

    print(f"Publication-ready C plot saved to {output_file}")
subprocess.run(["python", "11_Averaged_HW_Gallery_FOI_values.py"])
