import os
import pandas as pd
import numpy as np
import re
import plotly.graph_objects as go
from pathlib import Path  # Use Path consistently
import sys

# --- HTML STYLING (Unchanged) ---
HTML_STYLE = """
<style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f0f2f5; margin: 0; padding: 20px; }
    .page-wrapper { max-width: 1800px; margin: 0 auto; background-color: #ffffff; border-radius: 10px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); padding: 20px 40px; }
    h1 { text-align: center; color: #1c1e21; border-bottom: 2px solid #e7e7e7; padding-bottom: 15px; margin-bottom: 30px; }
    .gallery-container { display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; }
    .gallery-container a { text-decoration: none; color: inherit; flex: 1 1 30%; max-width: 32%; display: flex; }
    .analysis-section { display: flex; flex-direction: column; justify-content: flex-start; align-items: center; width: 100%; border: 1px solid #ddd; border-radius: 8px; padding: 15px; background-color: #ffffff; box-shadow: 0 2px 5px rgba(0,0,0,0.05); transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out; }
    .analysis-section img { width: 100%; height: auto; border-radius: 4px; }
    .analysis-section:hover { transform: translateY(-5px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
    .plot-info { text-align: center; font-weight: 600; margin-top: 12px; color: #333; font-size: 0.95em;}
    @media (max-width: 1600px) { .gallery-container a { max-width: 48%; } }
    @media (max-width: 900px) { .gallery-container a { max-width: 95%; } }
</style>
"""

# --- CONFIG (Using pathlib.Path) ---

# --- CORRECTED: Use Path objects from the start for consistency ---
main_folder = Path("/home/ajfla/TIMEFOIPROJECT/Codes/Codes_Updated/Codes/Onboarding_Data/LIN_PH106_F2025/")
input_dir = main_folder / "Individual_Time_FOI_Not_Mean_Shifted"
REPORTS_BASE_DIR = main_folder / "test_individual_not_shifted"
GALLERY_BASE_DIR = main_folder / "Gallery" / "4_individual_sorting_as_per_points"
CWID_LOOKUP_FILE = REPORTS_BASE_DIR / "test_individual_cwid_lookup_table.csv"

# Create necessary directories
GALLERY_BASE_DIR.mkdir(parents=True, exist_ok=True)

static_images_dir = GALLERY_BASE_DIR / "static_images"
static_images_dir.mkdir(parents=True, exist_ok=True)

custom_greyscale = [[0.0, "#D9D9D9"], [1.0, "#000000"]]

# --- Helper Functions ---
def load_cwid_lookup(file_path):
    # file_path is already a Path object from CONFIG
    if not file_path.exists():
        # --- CORRECTED: Moved print/exit before 'raise' to make them reachable ---
        print(f"--- ERROR: CWID lookup file not found at: {file_path}")
        print("--- Please run test_individual.py first to generate the detailed reports and lookup table. ---")
        sys.exit(1) # Exit with a non-zero status code
    try:
        df = pd.read_csv(file_path)
        df['Original_CWID'] = df['Original_CWID'].astype(str)
        return dict(zip(df['Original_CWID'], df['Encoded_CWID']))
    except (pd.errors.EmptyDataError, KeyError):
        return {}

def get_q_pairs(df):
    foi_cols = sorted([c for c in df.columns if "_FOI" in c and re.search(r"Q\d+", c)], key=lambda x: int(re.search(r"Q(\d+)", x).group(1)))
    time_cols = sorted([c for c in df.columns if "_TIME" in c and re.search(r"Q\d+", c)], key=lambda x: int(re.search(r"Q(\d+)", x).group(1)))
    return list(zip(foi_cols, time_cols))

# --- Main Script Logic ---
if __name__ == "__main__":
    cwid_mapping = load_cwid_lookup(CWID_LOOKUP_FILE)
    all_student_data_meta = []

    print("Pass 1: Reading and processing student data...")
    # --- CORRECTED: Use .iterdir() which is the pathlib way to list files ---
    for file_path in input_dir.iterdir():
        if file_path.suffix != ".csv":
            continue
        
        original_cwid = file_path.stem  # .stem gets filename without extension
        
        if original_cwid not in cwid_mapping:
            continue
            
        encoded_cwid = cwid_mapping[original_cwid]
        
        try:
            df = pd.read_csv(file_path)
            df.columns = df.columns.str.strip().str.replace(' ', '_')
            if "HW" not in df.columns:
                continue

            # --- CORRECTED: Get Q pairs *once* per file, not for every row ---
            q_pairs = get_q_pairs(df)
            if not q_pairs: # Skip if no (FOI, TIME) columns were found
                continue

            records = []
            for _, row in df.iterrows():
                # --- CORRECTED: Iterate over the pre-calculated q_pairs list ---
                for foi_col, time_col in q_pairs:
                    try:
                        q_num = int(re.search(r"Q(\d+)", foi_col).group(1))
                        foi = float(row[foi_col])
                        time_minutes = float(row[time_col])
                        if 0 <= foi <= 5 and 0 < time_minutes <= 1000:
                            records.append((foi, time_minutes, "MCQ" if q_num <= 11 else "Non-MCQ", q_num))
                    except (ValueError, TypeError):
                        continue
            
            if records:
                df_plot = pd.DataFrame(records, columns=["FOI", "Time", "Type", "Q"])
                all_student_data_meta.append({
                    'name': encoded_cwid,
                    'df_plot': df_plot,
                    'Total Questions': len(df_plot)
                })
        except Exception as e:
            print(f"Could not process {file_path.name}: {e}")

    # FIX 2 (User's fix, unchanged): Sort by question count (descending) and use name as a tie-breaker (ascending).
    all_student_data_meta.sort(key=lambda x: (-x.get('Total Questions', 0), x.get('name', '')))
    print(f"Found and processed data for {len(all_student_data_meta)} students, sorted by data point count (desc).")

    print("\nPass 2: Generating a static plot image for each student...")
    plot_data_list = []
    for student_meta in all_student_data_meta:
        df_plot = student_meta['df_plot']
        student_name = student_meta['name']
        data_points_count = student_meta['Total Questions']

        fig = go.Figure()
        y_max_plot = int((df_plot["Time"].max() + 9) // 10 * 10) if not df_plot.empty else 75
        if not df_plot.empty:
            df_density = df_plot.copy()
            df_density['binned_time'] = (df_density['Time'] / 2.0).round() * 2.0
            density_counts = df_density.groupby(['FOI', 'binned_time']).size().reset_index(name='count')
            fig.add_trace(go.Scatter(x=density_counts['FOI'], y=density_counts['binned_time'], mode='markers', marker=dict(symbol='square', color=density_counts['count'], colorscale=custom_greyscale, colorbar=dict(title='Count'), size=10, sizemin=4), name='Density', hovertemplate='FOI: %{x}<br>Time: ~%{y} min<br>Count: %{marker.color}<extra></extra>', showlegend=True))
        
        mcq = df_plot[df_plot["Type"] == "MCQ"]
        if not mcq.empty:
            fig.add_trace(go.Scatter(x=list(mcq["FOI"]), y=list(mcq["Time"]), mode='markers', name="MCQ", marker=dict(symbol='circle', size=8, color='rgba(255,255,255,0)', line=dict(width=1.5, color='crimson')), hovertemplate='FOI: %{x}<br>Time: %{y}<br>Q: %{customdata[0]}<br>Type: MCQ<extra></extra>', customdata=mcq[['Q']].values, showlegend=True))
            
        nm = df_plot[df_plot["Type"] == "Non-MCQ"]
        if not nm.empty:
            fig.add_trace(go.Scatter(x=list(nm["FOI"]), y=list(nm["Time"]), mode='markers', name="Non-MCQ", marker=dict(symbol='triangle-up', size=8, color='rgba(255,255,255,0)', line=dict(width=1.5, color='crimson')), hovertemplate='FOI: %{x}<br>Time: %{y}<br>Q: %{customdata[0]}<br>Type: Non-MCQ<extra></extra>', customdata=nm[['Q']].values, showlegend=True))
            
        fig.update_layout(title_text=f"<b>HW FOI vs. Time: {student_name}</b>", xaxis_title="Freak Out Index (FOI)", yaxis_title="Time (minutes)", plot_bgcolor="white", height=450, legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5), margin=dict(l=60, r=30, t=90, b=60))
        fig.update_xaxes(range=[-0.5, 5.5], showline=True, mirror=True, linecolor='black', tickvals=np.arange(0, 6), showgrid=False)
        fig.update_yaxes(range=[0, min(y_max_plot + 10, 45)], showline=True, mirror=True, linecolor='black', showgrid=False)
        
        image_filename = f"{student_name}.png"
        image_path = static_images_dir / image_filename # Use pathlib division
        fig.write_image(str(image_path), scale=2) # write_image needs a string
        
        plot_data_list.append({
            "id": student_name,
            "image_filename": image_filename,
            "Total Questions": data_points_count
        })
        print(f"-> Generated plot image: {image_filename} ({data_points_count} points)")
    
    # --- Pass 3: Assemble HTML gallery with RELATIVE paths for the web server ---
    print("\nPass 3: Assembling HTML gallery page with relative links...")
    output_html_path = GALLERY_BASE_DIR / "student_plots_gallery.html"
    
    html_content = f"<!DOCTYPE html><html><head><title>Student Analysis Gallery</title>{HTML_STYLE}</head><body>"
    html_content += '<div class="page-wrapper"><h1>Individual Student FOI vs. Time Gallery</h1>'
    html_content += '<div class="gallery-container">'

    for plot_data in plot_data_list:
        encoded_cwid = plot_data['id']
        image_filename = plot_data['image_filename']
        data_points_count = plot_data['Total Questions']

        # --- CORRECTED: Create a relative path for the HTML href ---
        # The gallery is at: .../Gallery/4_individual_sorting_as_per_points/
        # The report is at: .../test_individual/<cwid>/
        # We need to go up two levels (../../) to the main_folder,
        # then down into 'test_individual'.
        report_path = f"../../test_individual_not_shifted/{encoded_cwid}/{encoded_cwid}_full_report.html"
        
        # This path is correct, as 'static_images' is relative to the HTML file.
        image_src = f"static_images/{image_filename}"
        
        image_html = f'<img src="{image_src}" alt="Plot for student {encoded_cwid}">'
        info_html = f'<div class="plot-info">Student: {encoded_cwid}<br>Data Points: {data_points_count}</div>'
        
        html_content += f'<a href="{report_path}" target="_blank" title="Click to see detailed report for {encoded_cwid} ({data_points_count} data points)">'
        html_content += f'<div class="analysis-section">{image_html}{info_html}</div></a>\n'

    html_content += "</div></div></body></html>"
    
    with open(output_html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print("-" * 50)
    print(f"Successfully created gallery with server-compatible links: {output_html_path}")
