import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import re

plt.rcParams.update({
    'font.size': 13,
    'axes.titlesize': 15,
    'axes.labelsize': 15,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12
})


def extract_hw_number(folder_name):
    match = re.search(r'\d+', folder_name)
    return int(match.group()) if match else None


def regression_with_se(x, y):
    n = len(x)
    slope, intercept = np.polyfit(x, y, 1)

    y_pred = slope * x + intercept
    residuals = y - y_pred
    s_err = np.sqrt(np.sum(residuals**2) / (n - 2))

    x_mean = np.mean(x)
    Sxx = np.sum((x - x_mean)**2)

    slope_se = s_err / np.sqrt(Sxx)

    return slope, slope_se


def collect_B_values(base_directory):

    records = []

    for folder in os.listdir(base_directory):

        if not folder.startswith("HW"):
            continue

        hw_path = os.path.join(base_directory, folder)

        averages_file = None
        for file in os.listdir(hw_path):
            if "TimeFOI_averages" in file and file.endswith(".csv"):
                averages_file = os.path.join(hw_path, file)
                break

        if averages_file is None:
            continue

        df = pd.read_csv(averages_file)
        df = df[df["Questions"] != "Avg and Sum"]

        foi = df["FOI Average"].values
        ln_time = df["ln(Time Average)"].values

        slope, slope_se = regression_with_se(foi, ln_time)

        hw_num = extract_hw_number(folder)

        records.append((hw_num, slope))

    records.sort(key=lambda x: x[0])

    seq_numbers = np.arange(1, len(records) + 1)
    B_values = np.array([r[1] for r in records])

    return seq_numbers, B_values


# =========================
# MAIN
# =========================

if __name__ == "__main__":

    semesters = {
        "Fall 2024": "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinFall2024PH106",
        "Spring 2025": "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinSpring2025PH106",
        "Fall 2025": "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinFall2025PH106"
    }

    colors = {
        "Fall 2024": "#1f77b4",
        "Spring 2025": "#d62728",
        "Fall 2025": "#2ca02c"
    }

    fig, axes = plt.subplots(
        1,
        3,
        figsize=(15, 5),
        sharey=True
    )

    # Determine global y limits for consistency
    all_B = []

    semester_data = {}

    for semester, directory in semesters.items():
        x, B = collect_B_values(directory)
        semester_data[semester] = (x, B)
        all_B.extend(B)

    y_min = min(all_B) * 0.9
    y_max = max(all_B) * 1.1

    # Plot panels
    for ax, (semester, (x, B)) in zip(axes, semester_data.items()):

        ax.plot(
            x,
            B,
            marker='o',
            linewidth=2.5,
            markersize=6,
            color=colors[semester]
        )

        ax.set_title(semester)
        ax.set_ylim(y_min, y_max)
        ax.grid(alpha=0.25)

        ax.set_xticks(x)

    # Shared labels
    axes[0].set_ylabel("B Value (Slope)")
    fig.supxlabel("Homework Index")

    fig.suptitle("Slope (B) Across Homeworks by Semester", fontsize=18)

    plt.tight_layout(rect=[0, 0, 1, 0.92])

    output_file = "Semester_Small_Multiples_B_values.png"
    plt.savefig(output_file, dpi=300)
    plt.close()

    print(f"Small multiples plot saved to {os.path.abspath(output_file)}")