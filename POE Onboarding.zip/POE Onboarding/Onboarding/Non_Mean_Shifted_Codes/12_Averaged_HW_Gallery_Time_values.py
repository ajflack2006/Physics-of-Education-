import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import re

plt.rcParams.update({
    'font.size': 14,
    'axes.titlesize': 16,
    'axes.labelsize': 15,
    'xtick.labelsize': 13,
    'ytick.labelsize': 13,
    'legend.fontsize': 12
})


def extract_hw_number(folder_name):
    match = re.search(r'\d+', folder_name)
    return int(match.group()) if match else None


def mean_and_ci(values):
    n = len(values)
    mean = np.mean(values)
    se = np.std(values, ddof=1) / np.sqrt(n)
    ci_95 = 1.96 * se
    return mean, ci_95


def collect_Time_values(base_directory):

    records = []

    for folder in os.listdir(base_directory):

        if not folder.startswith("HW"):
            continue

        hw_path = os.path.join(base_directory, folder)

        # ---- Robust file detection ----
        averages_file = None
        for file in os.listdir(hw_path):
            if "TimeFOI_averages" in file and file.endswith(".csv"):
                averages_file = os.path.join(hw_path, file)
                break

        if averages_file is None:
            continue

        df = pd.read_csv(averages_file)
        df = df[df["Questions"] != "Avg and Sum"]

        time_vals = df["Time Average"].values
        mean, ci = mean_and_ci(time_vals)

        hw_num = extract_hw_number(folder)

        records.append((hw_num, mean, ci, folder))

    # ---- Sort by actual HW number ----
    records.sort(key=lambda x: x[0])

    # ---- Sequential index 1..N ----
    seq_numbers = np.arange(1, len(records) + 1)

    Time_means = np.array([r[1] for r in records])
    Time_errors = np.array([r[2] for r in records])
    labels = [r[3] for r in records]

    return seq_numbers, Time_means, Time_errors, labels


if __name__ == "__main__":

    base_directory = "/home/ajfla/TIMEFOIPROJECT/Codes/Codes_Updated/Codes/Onboarding_Data/LIN_PH106_F2025"

    seq_numbers, Time_means, Time_errors, labels = collect_Time_values(base_directory)

    plt.figure(figsize=(10, 6))

    plt.plot(seq_numbers, Time_means, marker='o', label="Mean Time")

    plt.errorbar(
        seq_numbers,
        Time_means,
        yerr=Time_errors,
        fmt='none',
        capsize=4
    )

    plt.xlabel("Homework Index")
    plt.ylabel("Time (minutes)")
    plt.title("Mean Time Across Homeworks\n\n", loc='left')

    plt.xticks(seq_numbers)   # 1..N evenly spaced

    plt.grid(alpha=0.25)
    plt.legend(frameon=False)

    output_file = os.path.join(
        base_directory,
        "All_Homeworks_Time_PUBLICATION.png"
    )

    plt.tight_layout()
    plt.savefig(output_file, dpi=300)
    plt.close()

    print(f"Time plot saved to {output_file}")