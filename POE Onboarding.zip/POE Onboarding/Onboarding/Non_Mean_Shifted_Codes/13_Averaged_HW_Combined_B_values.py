import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import re

plt.rcParams.update({
    'font.size': 14,
    'axes.titlesize': 18,
    'axes.labelsize': 16,
    'xtick.labelsize': 13,
    'ytick.labelsize': 13,
    'legend.fontsize': 13
})


def extract_hw_number(folder_name):
    match = re.search(r'\d+', folder_name)
    return int(match.group()) if match else None


def regression_with_se(x, y):
    n = len(x)
    slope, intercept = np.polyfit(x, y, 1)

    y_pred = slope * x + intercept
    residuals = y - y_pred
    s_err = np.sqrt(np.sum(residuals**2) / (n - 2))

    x_mean = np.mean(x)
    Sxx = np.sum((x - x_mean)**2)

    slope_se = s_err / np.sqrt(Sxx)

    return slope, slope_se


def collect_B_values(base_directory):

    records = []

    for folder in os.listdir(base_directory):

        if not folder.startswith("HW"):
            continue

        hw_path = os.path.join(base_directory, folder)

        averages_file = None
        for file in os.listdir(hw_path):
            if "TimeFOI_averages" in file and file.endswith(".csv"):
                averages_file = os.path.join(hw_path, file)
                break

        if averages_file is None:
            continue

        df = pd.read_csv(averages_file)
        df = df[df["Questions"] != "Avg and Sum"]

        foi = df["FOI Average"].values
        ln_time = df["ln(Time Average)"].values

        slope, slope_se = regression_with_se(foi, ln_time)

        hw_num = extract_hw_number(folder)

        records.append((hw_num, slope))

    records.sort(key=lambda x: x[0])

    seq_numbers = np.arange(1, len(records) + 1)

    B_values = np.array([r[1] for r in records])

    return seq_numbers, B_values


# =========================
# MAIN
# =========================

if __name__ == "__main__":

    semesters = {
        "Fall 2024": "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinFall2024PH106",
        "Spring 2025": "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinSpring2025PH106",
        "Fall 2025": "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinFall2025PH106"
    }

    colors = {
        "Fall 2024": "#1f77b4",
        "Spring 2025": "#d62728",
        "Fall 2025": "#2ca02c"
    }

    markers = {
        "Fall 2024": "o",
        "Spring 2025": "s",
        "Fall 2025": "^"
    }

    plt.figure(figsize=(11, 7))

    for semester, directory in semesters.items():

        x, B = collect_B_values(directory)

        plt.plot(
            x,
            B,
            marker=markers[semester],
            linewidth=2.8,
            markersize=7,
            color=colors[semester],
            label=semester
        )

    plt.xlabel("Homework Index")
    plt.ylabel("B Value (Slope)")
    plt.title("Slope (B) Across Homeworks — Semester Comparison")

    plt.grid(alpha=0.25)
    plt.legend(frameon=False)

    plt.tight_layout()

    output_file = "Semester_Comparison_B_values.png"
    plt.savefig(output_file, dpi=300)
    plt.close()

    print(f"Combined semester plot saved to {output_file}")