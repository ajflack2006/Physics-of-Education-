import pandas as pd
import base64
import os
import glob


def create_master_cwid_mapping():
    base_directory = "/home/ajfla/TIMEFOIPROJECT/Codes/Codes_Updated/Codes/Onboarding_Data/LIN_PH106_F2025/Raw_Data"

    # Find all HW CSV files like HW1.csv, HW2.csv, etc.
    csv_files = glob.glob(os.path.join(base_directory, "HW*PH106F25_raw.csv"))

    if not csv_files:
        print("No HW CSV files found.")
        return

    all_students = []

    for file in csv_files:
        print(f"Reading {file}")
        df = pd.read_csv(file)

        if df.shape[1] < 3:
            print(f"Skipping {file} (not enough columns)")
            continue

        name_column = df.columns[1]
        cwid_column = df.columns[2]

        students = df[[name_column, cwid_column]].copy()
        students.columns = ["Name", "CWID"]

        all_students.append(students)

    # Combine all homeworks
    combined_df = pd.concat(all_students, ignore_index=True)

    # Remove duplicates
    combined_df = combined_df.drop_duplicates()

    # Convert CWID to string
    combined_df["CWID"] = combined_df["CWID"].astype(str)

    # Base64 encode CWID
    combined_df["Base64_CWID"] = combined_df["CWID"].apply(
        lambda x: base64.b64encode(x.encode()).decode()
    )

    # Sort alphabetically by name
    combined_df = combined_df.sort_values(by="Name").reset_index(drop=True)

    # Output file
    output_file = os.path.join(base_directory, "PH106_Master_CWID_Mapping.csv")
    combined_df.to_csv(output_file, index=False)

    print(f"\nMaster CWID Mapping saved to:\n{output_file}")


if __name__ == "__main__":
    create_master_cwid_mapping()