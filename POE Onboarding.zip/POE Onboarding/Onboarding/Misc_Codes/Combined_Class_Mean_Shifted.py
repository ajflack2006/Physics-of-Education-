import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
import glob
import math
import scipy.stats as stats

# --- CONFIGURATION ---
CLASS_PATHS = [
    "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinFall2025PH106",
    "/home/ajfla/TIMEFOIPROJECT/LinResearchData/LinSpring2025PH106"
]

OUTPUT_DIR = "/home/ajfla/TIMEFOIPROJECT/LinResearchData/Combined_Class_Reports"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def load_and_merge_data(paths):
    all_data = []

    for path in paths:
        class_name = os.path.basename(path)
        time_dir = os.path.join(path, "Individual_Time_FOI_Student_Mean_Centered")
        corr_dir = os.path.join(path, "Individual_Correctness")

        if not os.path.exists(time_dir):
            print(f"Skipping {class_name}: Time directory not found.")
            continue

        time_files = glob.glob(os.path.join(time_dir, "*.csv"))
        for t_file in time_files:
            cwid = os.path.basename(t_file).replace('.csv', '')
            try:
                df_student_time = pd.read_csv(t_file)
                c_file = os.path.join(corr_dir, f"{cwid}_correctness.csv")
                if not os.path.exists(c_file): continue

                df_corr = pd.read_csv(c_file)
                df_corr['HW_MATCH'] = df_corr['HW'].astype(str).str.replace(" ", "").str.upper()

                for _, row in df_student_time.iterrows():
                    hw_id_clean = str(row['HW']).replace(" ", "").upper()
                    hw_grades = df_corr[df_corr['HW_MATCH'] == hw_id_clean]

                    if not hw_grades.empty:
                        for col_name in df_student_time.columns:
                            if 'FOI' in col_name:
                                q_id = col_name.split(' ')[0].upper()
                                time_col = f"{q_id} TIME"
                                grade_col = next((c for c in hw_grades.columns if c.upper() == q_id), None)

                                if time_col in df_student_time.columns and grade_col:
                                    foi_val, time_val, grade_val = row[col_name], row[time_col], hw_grades[grade_col].iloc[0]
                                    if pd.notnull(foi_val) and pd.notnull(time_val) and pd.notnull(grade_val):
                                        all_data.append({
                                            'Class': class_name,
                                            'Student': cwid,
                                            'HW': hw_id_clean,
                                            'Question': q_id,
                                            'FOI': foi_val,
                                            'Time': time_val,
                                            'Grade': grade_val
                                        })
            except Exception:
                continue

    return pd.DataFrame(all_data)

# --- LRT calculation ---
def calculate_lrt(df_slice, threshold):
    if df_slice.empty or len(df_slice) < 2:
        return 0.0
    pass_foi = df_slice[df_slice['Grade'] >= threshold]['FOI']
    fail_foi = df_slice[df_slice['Grade'] < threshold]['FOI']

    if len(pass_foi) < 2 or len(fail_foi) < 2:
        return 0.0

    mu0, sigma0 = df_slice['FOI'].mean(), df_slice['FOI'].std()
    logL0 = np.sum(stats.norm.logpdf(df_slice['FOI'], loc=mu0, scale=sigma0))

    mu1, sigma1 = pass_foi.mean(), pass_foi.std()
    mu2, sigma2 = fail_foi.mean(), fail_foi.std()
    logL1 = np.sum(stats.norm.logpdf(pass_foi, loc=mu1, scale=sigma1)) + \
            np.sum(stats.norm.logpdf(fail_foi, loc=mu2, scale=sigma2))

    lrt_value = -2 * (logL0 - logL1)
    return max(lrt_value, 0.0)

# --- Plotting function ---
def create_final_plot(df, title, filename):
    if df.empty: return

    foi_bins = [(-3, -2), (-2, -1), (-1, 0), (0, 1), (1, 2), (2, 3)]
    fixed_x_max = 30
    bin_size = 2
    threshold_init = 10

    # Calculate Max Bar Height for histograms
    max_bar_height = 0
    time_bins = np.arange(0, fixed_x_max + bin_size, bin_size)
    for low, high in foi_bins:
        slice_times = df[(df['FOI'] >= low) & (df['FOI'] <= high)]['Time']
        if not slice_times.empty:
            counts, _ = np.histogram(slice_times, bins=time_bins)
            if len(counts) > 0:
                max_bar_height = max(max_bar_height, counts.max())

    dynamic_fixed_y_max = max(50, max_bar_height * 1.1)
    y_tick_interval = 10 if dynamic_fixed_y_max < 150 else int(math.ceil(dynamic_fixed_y_max / 10))
    time_max_scatter = df['Time'].max() * 1.1 if not df['Time'].empty else 60

    # Titles
    titles = ["Main Distribution", "Total", "Red (Fail)", "Green (Pass)"]
    for l, h in foi_bins:
        titles.extend([f"FOI: [{l}, {h}]", "", ""])

    fig = make_subplots(
        rows=6, cols=4, column_widths=[0.40, 0.15, 0.15, 0.15],
        horizontal_spacing=0.08, vertical_spacing=0.05,
        subplot_titles=titles,
        specs=[[{"rowspan": 6}, {}, {}, {}], [None, {}, {}, {}], [None, {}, {}, {}],
               [None, {}, {}, {}], [None, {}, {}, {}], [None, {}, {}, {}]]
    )

    def compute_colors(df_in, thresh, mode='both'):
        if mode == 'green': return ['#2ecc71' if g >= thresh else 'rgba(0,0,0,0)' for g in df_in['Grade']]
        elif mode == 'red': return ['#e74c3c' if g < thresh else 'rgba(0,0,0,0)' for g in df_in['Grade']]
        return ['#2ecc71' if g >= thresh else '#e74c3c' for g in df_in['Grade']]

    # Scatter plot
    fig.add_trace(go.Scatter(
        x=df['FOI'], y=df['Time'], mode='markers',
        marker=dict(color=compute_colors(df, threshold_init, 'both'), size=9, opacity=0.6, line=dict(width=0.5, color='White')),
        text=[f"Class: {c}<br>SID: {s}<br>Grade: {g}" for c, s, g in zip(df['Class'], df['Student'], df['Grade'])],
        name='Data'
    ), row=1, col=1)

    red_indices, green_indices, grey_indices = [], [], []
    hist_style = dict(line=dict(color='black', width=1.2))

    for i, (low, high) in enumerate(foi_bins):
        slice_all = df[(df['FOI'] >= low) & (df['FOI'] <= high)]
        fig.add_trace(go.Histogram(x=slice_all['Time'], marker_color='#bdc3c7', opacity=0.4,
                                   marker=hist_style, xbins=dict(start=0, end=fixed_x_max, size=bin_size), showlegend=False), row=i+1, col=2)
        grey_indices.append(len(fig.data)-1)
        fig.add_trace(go.Histogram(x=slice_all[slice_all['Grade'] < threshold_init]['Time'], marker_color='#e74c3c', opacity=0.8,
                                   marker=hist_style, xbins=dict(start=0, end=fixed_x_max, size=bin_size), showlegend=False), row=i+1, col=3)
        red_indices.append(len(fig.data)-1)
        fig.add_trace(go.Histogram(x=slice_all[slice_all['Grade'] >= threshold_init]['Time'], marker_color='#2ecc71', opacity=0.8,
                                   marker=hist_style, xbins=dict(start=0, end=fixed_x_max, size=bin_size), showlegend=False), row=i+1, col=4)
        green_indices.append(len(fig.data)-1)

    # Slider steps with LRT
    steps = []
    for val in range(0, 11):
        new_x = [None] * len(fig.data)
        new_x[0] = df['FOI']
        for i, (low, high) in enumerate(foi_bins):
            slice_all = df[(df['FOI'] >= low) & (df['FOI'] <= high)]
            new_x[grey_indices[i]] = slice_all['Time']
            new_x[red_indices[i]] = slice_all[slice_all['Grade'] < val]['Time']
            new_x[green_indices[i]] = slice_all[slice_all['Grade'] >= val]['Time']

        lrt_val = calculate_lrt(df, val)

        steps.append(dict(
            method="update",
            label=str(val),
            args=[{"x": new_x, "marker.color": [compute_colors(df, val, 'both')] + [fig.data[j].marker.color for j in range(1, len(fig.data))]},
                  {"annotations": [dict(x=2.5, y=1.05, xref='x', yref='paper', text=f"<b>LRT: {lrt_val:.3f}</b>", showarrow=False, font=dict(size=18, color='darkblue'))]}]
        ))

    # Fixed/dynamic scales
    fixed_scale = {f"xaxis{k}.range": [0, fixed_x_max] for k in range(2, 20)}
    fixed_scale.update({f"yaxis{k}.range": [0, dynamic_fixed_y_max] for k in range(2, 20)})
    fixed_scale.update({f"yaxis{k}.dtick": y_tick_interval for k in range(2, 20)})
    fixed_scale.update({f"xaxis{k}.autorange": False for k in range(2, 20)})
    fixed_scale.update({f"yaxis{k}.autorange": False for k in range(2, 20)})

    dynamic_scale = {f"xaxis{k}.autorange": True for k in range(2, 20)}
    dynamic_scale.update({f"yaxis{k}.autorange": True for k in range(2, 20)})
    dynamic_scale.update({f"yaxis{k}.dtick": None for k in range(2, 20)})
    dynamic_scale.update({f"yaxis{k}.nticks": 6 for k in range(2, 20)})

    fig.update_layout(
        title=dict(text=f"<b>{title}</b><br><sup>N = {len(df)} | Fixed Y-Limit: {int(dynamic_fixed_y_max)}</sup>", x=0.05),
        template="plotly_white",
        updatemenus=[
            dict(type="buttons", direction="right", active=0, x=0.15, xanchor="left", y=1.12, buttons=[
                dict(label="Show All", method="restyle", args=[{"marker.color": [compute_colors(df, threshold_init, 'both')]}, [0]]),
                dict(label="Pass Only", method="restyle", args=[{"marker.color": [compute_colors(df, threshold_init, 'green')]}, [0]]),
                dict(label="Fail Only", method="restyle", args=[{"marker.color": [compute_colors(df, threshold_init, 'red')]}, [0]])
            ]),
            dict(type="buttons", direction="right", active=0, x=0.55, xanchor="left", y=1.12, buttons=[
                dict(label="Fixed Scaling", method="relayout", args=[fixed_scale]),
                dict(label="Dynamic Scaling", method="relayout", args=[dynamic_scale])
            ])
        ],
        sliders=[dict(active=threshold_init, currentvalue={"prefix": "Grade Threshold: "}, pad={"t": 30}, steps=steps, len=0.3, x=0.05)],
        height=1500, margin=dict(l=70, r=40, t=150, b=80)
    )

    fig.update_xaxes(title_text="FOI (Mean Centered)", range=[-3.1, 3.1], row=1, col=1)
    fig.update_yaxes(title_text="Time (Min)", range=[0, time_max_scatter], row=1, col=1)

    for r in range(1, 7):
        for c in [2, 3, 4]:
            fig.update_xaxes(range=[0, fixed_x_max], dtick=bin_size, row=r, col=c, autorange=False)
            fig.update_yaxes(range=[0, dynamic_fixed_y_max], dtick=y_tick_interval, nticks=6, tickfont=dict(size=9), row=r, col=c, autorange=False)

    fig.write_html(filename)

# --- MAIN ---
if __name__ == "__main__":
    df_combined = load_and_merge_data(CLASS_PATHS)

    if not df_combined.empty:
        create_final_plot(df_combined, "Combined Multi-Class Analysis", f"{OUTPUT_DIR}/Combined_MultiClass_Master.html")

        # Per-class and per-HW plots
        for cls in df_combined['Class'].unique():
            cls_df = df_combined[df_combined['Class'] == cls]
            create_final_plot(cls_df, f"Class: {cls}", f"{OUTPUT_DIR}/Master_{cls}.html")

            for hw in cls_df['HW'].unique():
                hw_df = cls_df[cls_df['HW'] == hw]
                create_final_plot(hw_df, f"{cls} - Assignment: {hw}", f"{OUTPUT_DIR}/{cls}_Report_{hw}.html")

        print(f"Reports generated successfully in: {OUTPUT_DIR}")