import os
from pathlib import Path
import re
import webbrowser
import subprocess


# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---
# HTML STYLING:
# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---
HTML_STYLE = """
<style>
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        background-color: #f0f2f5;
        margin: 0;
        padding: 20px;
    }
    .page-wrapper {
        max-width: 1600px;
        margin: 0 auto;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        padding: 20px 40px;
    }
    h1 {
        text-align: center;
        color: #1c1e21;
        border-bottom: 2px solid #e7e7e7;
        padding-bottom: 15px;
        margin-bottom: 30px;
    }
    .gallery-container {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
    }
    .analysis-section {
        flex: 1 1 300px;
        max-width: 23%;
        display: flex;
        flex-direction: column;
        margin-bottom: 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        background-color: #fafafa;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    .analysis-section:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .analysis-section h2 {
        color: #333;
        margin-top: 0;
        padding-bottom: 10px;
        border-bottom: 1px solid #ccc;
        font-size: 1em;
        text-align: center;
    }
    .analysis-section img.gallery-image { /* Added .gallery-image */
        width: 100%;
        height: auto;
        display: block;
        border-radius: 5px;
        cursor: zoom-in; /* Add zoom-in cursor */
    }

    /* --- NEW MODAL (POPUP) STYLES --- */
    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1000; /* Sit on top */
        padding-top: 50px;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto; /* Enable scroll if needed */
        background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
    }
    .modal-content {
        margin: auto;
        display: block;
        width: 80%;
        max-width: 1200px;
    }
    .modal-content {
        animation-name: zoom;
        animation-duration: 0.3s;
    }
    @keyframes zoom {
        from {transform: scale(0.1)}
        to {transform: scale(1)}
    }
    .close-modal {
        position: absolute;
        top: 15px;
        right: 35px;
        color: #f1f1f1;
        font-size: 40px;
        font-weight: bold;
        transition: 0.3s;
        cursor: pointer;
    }
    .close-modal:hover,
    .close-modal:focus {
        color: #bbb;
        text-decoration: none;
    }
    /* --- END OF MODAL STYLES --- */

    @media (max-width: 1400px) {
        .analysis-section { max-width: 30%; }
    }
    @media (max-width: 992px) {
        .analysis-section { max-width: 45%; }
    }
    @media (max-width: 768px) {
        .analysis-section { max-width: 90%; }
    }
</style>
"""

def create_html_gallery(image_directory, output_html_path):
    """
    Scans a directory for PNG files, sorts them, and creates an HTML file
    to display them in a gallery format with a click-to-zoom modal.
    """
    print(f"Scanning for PNG images in: {image_directory}")

   
    
    try:
        image_files = sorted(
            [f.name for f in image_directory.iterdir() if f.suffix.lower() == '.png'],
            key=lambda x: [int(c) if c.isdigit() else c for c in re.split(r'(\d+)', x)]
        )
    except FileNotFoundError:
        print(f"Error: The directory '{image_directory}' was not found.")
        return

    if not image_files:
        print("No PNG images found in the directory. HTML file not created.")
        return

    print(f"Found {len(image_files)} images. Generating HTML gallery...")

    output_html_path.parent.mkdir(parents=True, exist_ok=True)

    # Use os.path.relpath to correctly calculate the path between sibling directories
    relative_image_dir = os.path.relpath(image_directory, output_html_path.parent)


    html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homework Analysis Gallery</title>
    {HTML_STYLE}
</head>
<body>
    <div class="page-wrapper">
        <h1>Overall Homework Analysis Reports</h1>
        <div class="gallery-container">
"""

    for image_file in image_files:
        #title = image_file.split('PH106')[0].replace('_', ' ').strip() + " Analysis"
        #image_path_uri = (image_directory / image_file).as_uri()

        title = image_file.split('PH106')[0].replace('_', ' ').strip() + " Analysis"
        
        # Convert the relative_image_dir (now a string) back to a Path object
        # before using the / operator for joining.
        image_path_uri = str(Path(relative_image_dir) / image_file).replace(os.path.sep, '/')

        html_content += f"""
            <div class="analysis-section">
                <h2>{title}</h2>
                <img src="{image_path_uri}" alt="Analysis for {title}" class="gallery-image">
            </div>
"""

    # Close the gallery and page wrapper
    html_content += """
        </div>
    </div>
"""

    # --- NEW: ADD THE MODAL HTML AND SCRIPT ---
    html_content += """
    <div id="imageModal" class="modal">
        <span class="close-modal">&times;</span>
        <img class="modal-content" id="modalImg">
    </div>

    <script>
        // Get the modal
        var modal = document.getElementById("imageModal");
        var modalImg = document.getElementById("modalImg");

        // Get all images with the class "gallery-image"
        var images = document.getElementsByClassName("gallery-image");
        
        // Loop through all images and add the click event
        for (var i = 0; i < images.length; i++) {
            images[i].onclick = function() {
                modal.style.display = "block";
                modalImg.src = this.src;
            }
        }

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close-modal")[0];

        // When the user clicks on <span> (x) or the modal background, close it
        span.onclick = function() {
            modal.style.display = "none";
        }
        modal.onclick = function(event) {
            // Close if background (not the image itself) is clicked
            if (event.target == modal) {
                 modal.style.display = "none";
            }
        }
    </script>
"""
    # --- END OF NEW SECTION ---

    # Close the final HTML tags
    html_content += """
</body>
</html>
"""

    with open(output_html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"Successfully created gallery: {output_html_path}")
    
    webbrowser.open_new_tab(output_html_path.as_uri())
    print("Opening gallery in your default web browser...")


if __name__ == "__main__":
    home_dir = Path.home()
    
    # --- MAIN CONFIGURATION ---
    main_folder = home_dir / "TIMEFOIPROJECT/Physics_Of_Education_Compiled_Data/Lin_PH106_F2024/"
    # ------------------------------------
    
    # --- Configuration ---
    default_image_dir = main_folder / "Overall_HW_Analysis"
    output_html_file = main_folder / "Gallery/6_Detailed_homeworks_gallery.html"

    print("--- HTML Gallery Generator (with Click-to-Zoom) ---")
    print(f"This script will look for images in: '{default_image_dir}'")
    
    use_default = input("Use this default directory? (yes/no): ").strip().lower()
    
    if use_default in ['yes', 'y', '']:
        image_dir_to_scan = default_image_dir
    else:
        custom_dir_str = input("Enter the full path to the image directory: ")
        image_dir_to_scan = Path(custom_dir_str)
        output_html_file = image_dir_to_scan / "gallery.html"
        
    create_html_gallery(image_dir_to_scan, output_html_file)
#subprocess.run(["python", "7_Averaged_HW_Gallery_scatter.py"])
